"""Test intégral des tâches (mêmes config.json et worker que l'interface)."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
ROOT = Path(__file__).resolve().parents[1]
WORKER = ROOT/'package/usr/share/recupstudio/worker.py'
REFS = Path(__file__).resolve().parent/'references'
def digest(path):
    with path.open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()
def job(base, name, *, cancel=False, **config):
    folder = base/name
    folder.mkdir()
    (folder/'config.json').write_text(json.dumps(config))
    (folder/'control.json').write_text(json.dumps({'cancel':cancel}))
    proc = subprocess.run([sys.executable, str(WORKER),'--job', str(folder)], timeout=90)
    status=json.loads((folder/'status.json').read_text())
    assert proc.returncode==0 or status['state'] in ('error','cancelled'), status
    return status, folder
def run(base):
    builder=base/'volume'
    src=ROOT/'tests'
    subprocess.run(['cc','-I'+str(src/'fatfs'),str(src/'volume.c'),str(src/'fatfs/ff.c'),'-o',builder],check=True)
    img=base/'partition.img'
    refs=sorted(p.name for p in REFS.iterdir())
    subprocess.run([builder,img,*refs],cwd=REFS,check=True)
    initial=digest(img)
    cfg={'source':str(img),'action':'metadata','categories':['all']}
    state,scan=job(base,'scan',**cfg)
    assert state['state']=='done' and state['count']==6,state
    rows=[json.loads(line) for line in (scan/'catalog.jsonl').read_text().splitlines()]
    assert all(row['path'].startswith('ESSAI/') for row in rows)
    dest=base/'restauration';dest.mkdir()
    restore=dict(action='restore',source=str(img),destination=str(dest),catalog=str(scan/'catalog.jsonl'),selected=[r['inode']+'|'+r['path'] for r in rows])
    state,_=job(base,'restore',**restore)
    assert state['count']==6 and state['state']=='done',state
    for path in sorted(dest.rglob('*')):
        if path.is_file():
            matches=[p for p in REFS.iterdir() if digest(p)==digest(path)]
            assert len(matches)==1 and matches[0].name!='TEMOIN.TXT',path
            print(matches[0].name,path.relative_to(dest),digest(path))
    again,_=job(base,'copies',**restore)
    assert again['count']==6 and len(list((dest/'ESSAI').iterdir()))==12
    state,_=job(base,'photos',**(cfg|{'categories':['images']}))
    assert state['count']==2
    state,_=job(base,'annuler',cancel=True,**cfg)
    assert state['state']=='cancelled',state
    empty=base/'vide.img'
    subprocess.run([builder,empty],check=True)
    state,_=job(base,'vide',**(cfg|{'source':str(empty)}))
    assert state['state']=='done' and state['count']==0
    unsupported=base/'inconnu.img';unsupported.write_bytes(b'\xff'*8192)
    state,_=job(base,'inconnu',**(cfg|{'source':str(unsupported)}))
    assert state['state']=='error'
    unsupported.chmod(0)
    state,_=job(base,'refuse',**(cfg|{'source':str(unsupported)}))
    assert state['state']=='error'
    assert digest(img)==initial
    if shutil.which('photorec'):
        deep=base/'profond';deep.mkdir()
        state,_=job(base,'signatures',action='signature',source=str(img),destination=str(deep),categories=['images'],filesystem='other',mode='free')
        hashes={digest(p) for p in deep.rglob('*') if p.is_file() and p.name!='report.xml'}
        assert state['state']=='done' and hashes=={digest(REFS/'CARTE.JPG'),digest(REFS/'CARTE.PNG')},(state,hashes)
        print('PhotoRec : JPEG et PNG identiques, aucun autre contenu.')
        exact=base/'precis';exact.mkdir()
        state,both=job(base,'avance',action='advanced',source=str(img),destination=str(exact),categories=['all'],families=['png'],filesystem='other',mode='free')
        assert state['state']=='done' and state['action']=='advanced',state
        assert len((both/'catalog.jsonl').read_text().splitlines())==6
        files=[p for p in exact.rglob('*') if p.is_file() and p.name!='report.xml']
        assert len(files)==1 and digest(files[0])==digest(REFS/'CARTE.PNG')
        print('Avancé : six entrées par nom, une seule signature PNG, témoin PNG exclu.')
    if shutil.which('ddrescue'):
        dst=base/'copie.img'
        clone=dict(action='clone',source=str(img),destination=str(dst))
        state,_=job(base,'clonage',**clone)
        assert state['state']=='done' and digest(dst)==initial,state
        state,_=job(base,'collision-clonage',**clone)
        assert state['state']=='error' and digest(dst)==initial
        print('ddrescue : copie de 64 Mio identique, écrasement refusé.')
    # Écraser le contenu exact dans UNE COPIE privée du volume synthétique.
    damaged=base/'ecrase.img'
    target=REFS/'NOTES.TXT'
    raw=img.read_bytes()
    assert raw.count(target.read_bytes())==1
    damaged.write_bytes(raw.replace(target.read_bytes(), b'\0'*target.stat().st_size))
    state,dc=job(base,'ecrase-scan',**(cfg|{'source':str(damaged)}))
    rows=[json.loads(line) for line in (dc/'catalog.jsonl').read_text().splitlines()]
    row=next(r for r in rows if r['name'].endswith('.TXT'))
    out=base/'perdu';out.mkdir()
    state,_=job(base,'ecrase-restauration',**(restore|{'source':str(damaged),'destination':str(out),'catalog':str(dc/'catalog.jsonl'),'selected':[row['inode']+'|'+row['path']]}))
    assert state.get('blanks')==1,state
    assert all(digest(p)!=digest(target) for p in out.rglob('*') if p.is_file())
    print('Texte écrasé : le nom persiste, le contenu original est irrécupérable.')
    img.touch()
    state,_=job(base,'modifiee',**restore)
    assert state['state']=='error'
    print('Métadonnées, sélection, collisions, image vide, format inconnu, accès refusé, annulation, image modifiée : OK.')
if __name__=='__main__':
    with tempfile.TemporaryDirectory() as tmp:run(Path(tmp))
