"""Cas de topologie simulés ; ne nécessite aucun périphérique physique."""
from pathlib import Path
import sys
import tempfile
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'package/usr/share/recupstudio'))
from common import safe_output, is_safe_usb_unmount
with tempfile.TemporaryDirectory() as folder:
    for mounts, comparison, allowed in [([], True, False),([], None, False),(['/media/cle'],False,False),([],False,True)]:
        with patch('common.valid_source',return_value='device'),patch('common.mounted_sources',return_value=mounts),patch('common.destination_on_source_disk',return_value=comparison):
            try: safe_output('/dev/source',folder)
            except ValueError: assert not allowed
            else: assert allowed
    disk={'type':'part','external':True,'mounted':True,'fstype':'vfat','mountpoints':['/']}
    assert not is_safe_usb_unmount(disk)
    assert is_safe_usb_unmount(disk|{'mountpoints':['/media/test/USB']})
print('Décisions de protection simulées : OK')
