/* FAT32 fixture. Only creates a NEW regular file, never accepts a device. */
#include "ff.h"
#include "diskio.h"
#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/* Fixture names are ASCII. FatFs handles the on-disk directory structures. */
WCHAR ff_oem2uni(WCHAR c, WORD cp) { return c < 128 ? c : 0; }
WCHAR ff_uni2oem(DWORD c, WORD cp) { return c < 128 ? c : 0; }
DWORD ff_wtoupper(DWORD c) { return c >= 'a' && c <= 'z' ? c-32 : c; }
static int image;
static const unsigned sectors = 131072;
DSTATUS disk_initialize(BYTE d) {return d ? 1 : 0;}
DSTATUS disk_status(BYTE d) {return d ? 1 : 0;}
DRESULT disk_read(BYTE d, BYTE *p, LBA_t s, UINT n) {
    return !d && s+n<=sectors && pread(image,p,512*n,512LL*s)==512*n ? RES_OK : RES_ERROR;
}
DRESULT disk_write(BYTE d, const BYTE *p,LBA_t s,UINT n) {
    return !d && s+n<=sectors && pwrite(image,p,512*n,512LL*s)==512*n ? RES_OK : RES_ERROR;
}
DRESULT disk_ioctl(BYTE d,BYTE cmd,void *p) {
    if (cmd==CTRL_SYNC) return fsync(image)==0 ? RES_OK : RES_ERROR;
    if (cmd==GET_SECTOR_COUNT) *(LBA_t*)p=sectors;
    else if (cmd==GET_BLOCK_SIZE) *(DWORD*)p=1;
    else return RES_PARERR;
    return RES_OK;
}
#define CHECK(expr) do { FRESULT r=(expr); if(r){fprintf(stderr,"%s -> %d\n",#expr,r);return 1;} }while(0)
int main(int argc,char **argv) {
    if(argc<2)return 1;
    image=open(argv[1],O_CREAT|O_EXCL|O_RDWR,0600);
    if(image<0 || ftruncate(image,512LL*sectors))return 1;
    BYTE work[4096]; FATFS fs;
    MKFS_PARM fmt={.fmt=FM_FAT32|FM_SFD,.au_size=512};
    if(getenv("RECUP_FIXTURE_EXFAT")) fmt.fmt=FM_EXFAT|FM_SFD;
    CHECK(f_mkfs("",&fmt,work,sizeof work)); CHECK(f_mount(&fs,"",1));
    CHECK(f_mkdir("ESSAI"));
    for(int i=2;i<argc;i++){
        FILE *ref=fopen(argv[i],"rb"); if(!ref)return 1;
        char path[128]; snprintf(path,sizeof path,"ESSAI/%s",argv[i]);
        FIL file; CHECK(f_open(&file,path,FA_CREATE_NEW|FA_WRITE));
        size_t nr; UINT nw;
        while((nr=fread(work,1,sizeof work,ref))){
            CHECK(f_write(&file,work,nr,&nw)); if(nw!=nr)return 1;
        }
        if(ferror(ref))return 1;
        fclose(ref); CHECK(f_close(&file));
    }
    for(int i=2;i<argc;i++) {
        if(!strncmp(argv[i],"TEMOIN.",7))continue;
        char path[128]; snprintf(path,sizeof path,"ESSAI/%s",argv[i]);
        CHECK(f_unlink(path));
    }
    CHECK(f_mount(NULL,"",0));return close(image)!=0;
}
