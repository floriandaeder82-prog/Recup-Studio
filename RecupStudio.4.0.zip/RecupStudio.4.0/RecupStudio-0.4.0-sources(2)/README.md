# Récup Studio 0.4.0
Application GNOME en français. Lancer ./build.sh pour créer le paquet Debian avec dpkg-deb.
L’arborescence package/ contient tous les fichiers installés. Aucun outil de récupération n’est embarqué.
Le guide graphique et le rapport sont dans package/usr/share/doc/recupstudio.
L’image de démonstration est demo/Essai-FAT32.img. Les six originaux et les deux témoins sont dans tests/references.
Pour les tests, installer Python 3.11+, un compilateur C, sleuthkit, testdisk, gddrescue et util-linux.
Exécuter python3 tests/validate.py avec un compte ordinaire. Pour le second système de fichiers, exécuter RECUP_FIXTURE_EXFAT=1 python3 tests/validate.py.
Exécuter python3 tests/protections.py pour les cas simulés de topologie disque.
Le code de Récup Studio est sous GPL-3.0-or-later. Les sources FatFs de tests gardent leurs mentions de licence d’origine.
