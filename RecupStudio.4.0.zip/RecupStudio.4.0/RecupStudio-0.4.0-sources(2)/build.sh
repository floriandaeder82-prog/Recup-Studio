#!/bin/sh
set -eu
cd "$(dirname "$0")"
dpkg-deb --root-owner-group --build package "${1:-RecupStudio-Ubuntu-0.4.0.deb}"
