#!/usr/bin/python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Récup Studio 0.3 — native GNOME GTK4 / libadwaita frontend.

The tested file recovery worker from 0.2 is kept intact. UI never scans a
physical device itself and never performs disk operations on GTK's main loop.
"""
from __future__ import annotations

import datetime as dt
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import threading
import traceback
import uuid

import gi
gi.require_version('Gtk', '4.0')
gi.require_version('Adw', '1')
gi.require_version('GdkPixbuf', '2.0')
gi.require_version('Pango', '1.0')
from gi.repository import Adw, Gtk, GLib, Gio, Gdk, GdkPixbuf, Pango

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import (VERSION, lsblk_data, flatten_devices, is_safe_usb_unmount,
                    valid_source, safe_output, human_size, atomic_json,
                    read_json, session_dir, device_identity, ensure_default_recovery_directory, existing_destination)
from formats import CATEGORIES, category_for_name, normalize_categories

WORKER = Path(__file__).resolve().parent / 'worker.py'
CATEGORY_KEYS = list(CATEGORIES)
FILTERS = [('Tous les fichiers', 'all')] + [(v[0], k) for k,v in CATEGORIES.items()] + [('Autres fichiers', 'other')]


def background(work, callback):
    """Invoke callback(result, error) from GTK thread, never a Python thread."""
    def run():
        try:
            result, error = work(), None
        except Exception as exc:
            result, error = None, str(exc)
        def finish():
            try:
                callback(result, error)
            except Exception:
                # Exceptions raised from a GTK idle callback are otherwise
                # hidden when the program is launched from the desktop icon.
                try:
                    from launcher import log_message
                    log_message('Erreur dans un rappel graphique :\n' + traceback.format_exc())
                except Exception:
                    pass
            return GLib.SOURCE_REMOVE
        GLib.idle_add(finish)
    threading.Thread(target=run, daemon=True).start()


def box(orientation=Gtk.Orientation.VERTICAL, spacing=10):
    return Gtk.Box(orientation=orientation, spacing=spacing)


def label(text, css=None, wrap=False):
    widget = Gtk.Label(label=str(text), xalign=0)
    if css: widget.add_css_class(css)
    widget.set_wrap(wrap)
    widget.set_selectable(False)
    return widget


def button(text, callback, css=None, icon=None):
    # Gtk.Button.set_icon_name() *replaces* a label on some GTK versions.
    # Compose the two native widgets so action labels stay readable.
    b = Gtk.Button()
    if icon:
        content = box(Gtk.Orientation.HORIZONTAL, 7)
        content.set_halign(Gtk.Align.CENTER)
        content.append(Gtk.Image.new_from_icon_name(icon))
        content.append(Gtk.Label(label=text))
        b.set_child(content)
    else:
        b.set_label(text)
    if css: b.add_css_class(css)
    b.connect('clicked', lambda *_: callback())
    return b


class StudioWindow(Adw.ApplicationWindow):
    def __init__(self, app):
        super().__init__(application=app, title='Récup Studio')
        self.set_default_size(1120, 780)
        self.set_size_request(740, 550)
        self.devices = []
        self.device_rows = {}
        self.selected_device = None
        self.selected_source = None
        self.destination = Path.home() / 'Récupérations'
        self.image_output = ''
        self.result_items = []
        self.result_mode = None
        self.result_base = None
        self.result_source = None
        self.catalog = None
        self.selected_ids = set()
        self.page = 0
        self.page_size = 60
        self.visible_records = []
        self.job = None
        self.proc = None
        self._scan_verifying = False
        self._loading = False
        self._preview_serial = 0
        self._active_choosers = []  # GTK native dialogs need a strong reference
        self._build_shell()
        self._build_support()
        self._build_search()
        self._build_results()
        self._build_image()
        self._build_help()
        self.navigate('support')
        GLib.timeout_add(150, self._first_refresh)
        GLib.timeout_add_seconds(1, self.poll)
        self.connect('close-request', self._on_close)

    def _first_refresh(self):
        self.refresh_devices()
        return GLib.SOURCE_REMOVE

    def _build_shell(self):
        toolbar = Adw.ToolbarView()
        header = Adw.HeaderBar()
        header.set_title_widget(Adw.WindowTitle.new('Récup Studio', 'Récupération de données · v' + VERSION))
        refresh = Gtk.Button.new_from_icon_name('view-refresh-symbolic')
        refresh.set_tooltip_text('Actualiser les supports')
        refresh.connect('clicked', lambda *_: self.refresh_devices())
        header.pack_end(refresh)
        toolbar.add_top_bar(header)

        root = box(Gtk.Orientation.VERTICAL, 0)
        center = box(Gtk.Orientation.HORIZONTAL, 0)
        center.set_vexpand(True)
        root.append(center)

        sidebar = box(spacing=6)
        sidebar.set_size_request(224, -1)
        sidebar.add_css_class('navigation-sidebar')
        sidebar.set_margin_top(18)
        sidebar.set_margin_bottom(14)
        sidebar.set_margin_start(10)
        sidebar.set_margin_end(10)
        headline = box(Gtk.Orientation.HORIZONTAL, 10)
        icon = Gtk.Image.new_from_icon_name('drive-harddisk-symbolic')
        icon.set_pixel_size(26)
        headline.append(icon)
        name = label('RÉCUP STUDIO', 'heading')
        headline.append(name)
        headline.set_margin_bottom(18)
        headline.set_margin_start(8)
        sidebar.append(headline)
        self.nav = Gtk.ListBox()
        self.nav.set_selection_mode(Gtk.SelectionMode.SINGLE)
        self.nav.add_css_class('navigation-sidebar')
        self.nav_rows = {}
        for key, text, icon_name in [
            ('support','Supports','drive-removable-media-symbolic'),
            ('scan','Rechercher','system-search-symbolic'),
            ('results','Fichiers retrouvés','folder-documents-symbolic'),
            ('image','Image disque','drive-harddisk-symbolic'),
            ('help','Aide et sécurité','dialog-information-symbolic')]:
            row = Gtk.ListBoxRow()
            h = box(Gtk.Orientation.HORIZONTAL, 13)
            h.set_margin_top(12); h.set_margin_bottom(12)
            h.set_margin_start(14); h.set_margin_end(12)
            img = Gtk.Image.new_from_icon_name(icon_name)
            img.set_pixel_size(18)
            h.append(img)
            h.append(label(text))
            row.set_child(h)
            self.nav.append(row)
            self.nav_rows[key] = row
        self.nav.connect('row-selected', self._nav_changed)
        sidebar.append(self.nav)
        spacer = Gtk.Box(); spacer.set_vexpand(True)
        sidebar.append(spacer)
        privacy = label('100 % local · Aucun compte requis', 'dim-label', True)
        privacy.set_margin_start(8)
        sidebar.append(privacy)
        center.append(sidebar)
        center.append(Gtk.Separator(orientation=Gtk.Orientation.VERTICAL))

        self.stack = Gtk.Stack()
        self.stack.set_hexpand(True)
        self.stack.set_vexpand(True)
        self.stack.set_transition_type(Gtk.StackTransitionType.CROSSFADE)
        center.append(self.stack)

        bottom = box(Gtk.Orientation.HORIZONTAL, 12)
        bottom.set_margin_start(22); bottom.set_margin_end(22)
        bottom.set_margin_top(10); bottom.set_margin_bottom(10)
        self.spinner = Gtk.Spinner()
        bottom.append(self.spinner)
        self.progress = Gtk.ProgressBar()
        self.progress.set_size_request(105,-1)
        self.progress.set_visible(False)
        bottom.append(self.progress)
        self.status = label('Prêt', 'dim-label')
        self.status.set_hexpand(True)
        self.status.set_ellipsize(Pango.EllipsizeMode.END)
        bottom.append(self.status)
        self.stop_btn = button('Arrêter', self.cancel, 'destructive-action', 'process-stop-symbolic')
        self.stop_btn.set_sensitive(False)
        bottom.append(self.stop_btn)
        root.append(Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL))
        root.append(bottom)
        toolbar.set_content(root)
        self.set_content(toolbar)

    def _nav_changed(self, listbox, row):
        if row is None:return
        for key, widget in self.nav_rows.items():
            if row == widget:
                self.stack.set_visible_child_name(key)
                if key == 'results': self.render_results()
                return

    def navigate(self, key):
        self.nav.select_row(self.nav_rows[key])

    def _new_page(self, key, title, subtitle, width=1020):
        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        scroll.set_vexpand(True)
        layout = box(spacing=17)
        layout.set_margin_start(30)
        layout.set_margin_end(30)
        layout.set_margin_top(24)
        layout.set_margin_bottom(26)
        clamp = Adw.Clamp()
        clamp.set_maximum_size(width)
        clamp.set_child(layout)
        scroll.set_child(clamp)
        self.stack.add_named(scroll, key)
        heading = label(title, 'title-1', True)
        layout.append(heading)
        hint = label(subtitle, 'dim-label', True)
        hint.set_margin_top(0)
        hint.set_margin_bottom(6)
        layout.append(hint)
        return layout

    def _group(self, title, description=None):
        group = Adw.PreferencesGroup()
        group.set_title(title)
        if description: group.set_description(description)
        return group

    def _row(self, title, subtitle=None):
        row = Adw.ActionRow()
        row.set_title(title)
        if subtitle: row.set_subtitle(subtitle)
        return row

    def _notice(self, text):
        frame = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        frame.add_css_class('card')
        frame.set_margin_top(6)
        frame.set_margin_bottom(4)
        frame.set_margin_start(0)
        frame.set_margin_end(0)
        frame.set_size_request(-1, 58)
        icon = Gtk.Image.new_from_icon_name('dialog-warning-symbolic')
        icon.set_margin_start(16)
        frame.append(icon)
        msg = label(text, 'dim-label', True)
        msg.set_margin_end(16)
        msg.set_margin_top(12); msg.set_margin_bottom(12)
        frame.append(msg)
        return frame

    def _dialog(self, title, body, *, confirm=None, confirm_text='Continuer'):
        dlg = Adw.MessageDialog.new(self, title, str(body))
        dlg.add_response('close' if confirm is None else 'cancel',
                         'Fermer' if confirm is None else 'Annuler')
        if confirm is not None:
            dlg.add_response('ok', confirm_text)
            dlg.set_response_appearance('ok', Adw.ResponseAppearance.SUGGESTED)
            dlg.connect('response', lambda _d, resp: confirm() if resp == 'ok' else None)
        dlg.present()

    def _file_dialog(self, title, action, done, *, image_filter=False, suggested=None):
        chooser = Gtk.FileChooserNative.new(title, self, action,
            'Ouvrir' if action == Gtk.FileChooserAction.OPEN else
            'Enregistrer' if action == Gtk.FileChooserAction.SAVE else 'Choisir',
            'Annuler')
        if image_filter:
            filt = Gtk.FileFilter()
            filt.set_name('Images brutes (.img, .dd, .raw, .bin)')
            for pattern in ('*.img','*.dd','*.raw','*.bin'): filt.add_pattern(pattern)
            chooser.add_filter(filt)
        if action == Gtk.FileChooserAction.SELECT_FOLDER:
            # Start in the home directory, not on a possibly inaccessible USB volume.
            try: chooser.set_current_folder(Gio.File.new_for_path(str(Path.home())))
            except (GLib.Error, AttributeError, TypeError): pass
        if suggested and action == Gtk.FileChooserAction.SAVE:
            chooser.set_current_name(suggested)
        def response(dialog, code):
            try:
                if code == Gtk.ResponseType.ACCEPT:
                    gfile = dialog.get_file()
                    if gfile and gfile.get_path():
                        done(gfile.get_path())
                    else:
                        self._dialog('Chemin inaccessible',
                            'Le dossier choisi n’est pas accessible. Pour une destination, '
                            'utilisez « Dossier personnel » ou « Saisir le chemin… ».')
            except Exception as exc:
                self._dialog('Sélection impossible', str(exc))
            finally:
                dialog.destroy()
                if dialog in self._active_choosers:
                    self._active_choosers.remove(dialog)
        chooser.connect('response', response)
        self._active_choosers.append(chooser)
        chooser.show()

    def _build_support(self):
        p = self._new_page('support', 'Choisir un support',
            'Sélectionnez la partition de votre clé USB ou ouvrez une image brute de disque.')
        group = self._group('Disques et partitions', 'Une clé USB apparaît avec sa capacité et son point de montage.')
        p.append(group)
        actions = box(Gtk.Orientation.HORIZONTAL, 9)
        actions.append(button('Actualiser', self.refresh_devices, icon='view-refresh-symbolic'))
        actions.append(button('Ouvrir une image disque…', self.open_image_source,
                             icon='folder-open-symbolic'))
        p.append(actions)
        device_panel = Gtk.ListBox()
        device_panel.add_css_class('boxed-list')
        device_panel.set_selection_mode(Gtk.SelectionMode.SINGLE)
        device_panel.connect('row-selected', self._device_selected)
        self.devices_list = device_panel
        p.append(device_panel)
        self.source_notice = label('Détection des supports en cours…', 'dim-label', True)
        p.append(self.source_notice)
        bar = box(Gtk.Orientation.HORIZONTAL, 10)
        self.unmount_btn = button('Démonter sans débrancher', self.unmount_usb,
                                  icon='media-eject-symbolic')
        self.unmount_btn.set_sensitive(False)
        bar.append(self.unmount_btn)
        grow = Gtk.Box(); grow.set_hexpand(True); bar.append(grow)
        bar.append(button('Continuer', lambda:self.navigate('scan'), 'suggested-action',
                          'go-next-symbolic'))
        p.append(bar)
        p.append(self._notice('Si vous avez supprimé des fichiers, ne copiez plus rien sur le support à récupérer.'))

    def refresh_devices(self):
        self.source_notice.set_label('Détection des supports en cours…')
        def task():
            return sorted(flatten_devices(lsblk_data()),
                          key=lambda d:(not d.get('external'), d.get('type') != 'part', d.get('path') or ''))
        background(task, self._devices_ready)

    def _devices_ready(self, devices, error):
        if error:
            self.source_notice.set_label('Erreur de détection : ' + error)
            return
        self.devices = devices
        self.device_rows.clear()
        while (child := self.devices_list.get_first_child()) is not None:
            self.devices_list.remove(child)
        selected = None
        for item in devices:
            if item.get('type') not in ('disk','part','lvm','crypt') or not item.get('path'):
                continue
            path = item['path']
            title = str(item.get('label') or item.get('device_model') or path).strip()
            if title != path: title += '  ·  ' + path
            mounts = item.get('nested_mounts') or []
            system = any(str(m) in ('/','/home') for m in mounts)
            state = 'Système actif' if system else ('Monté' if mounts else 'Non monté')
            details = f'{human_size(item.get("size"))}   ·   {item.get("fstype") or "format inconnu"}   ·   {state}'
            row = Gtk.ListBoxRow()
            row_body = box(Gtk.Orientation.HORIZONTAL, 13)
            row_body.set_margin_top(10); row_body.set_margin_bottom(10)
            row_body.set_margin_start(14); row_body.set_margin_end(14)
            graphic = Gtk.Image.new_from_icon_name('drive-removable-media-symbolic'
                if item.get('external') else 'drive-harddisk-symbolic')
            graphic.set_pixel_size(24)
            row_body.append(graphic)
            info = box(spacing=3)
            info.set_hexpand(True)
            info.append(label(title))
            info.append(label(details, 'dim-label'))
            row_body.append(info)
            row.set_child(row_body)
            self.devices_list.append(row)
            self.device_rows[row] = item
            if path == self.selected_source: selected = row
        if selected: self.devices_list.select_row(selected)
        self.source_notice.set_label('Choisissez la PARTITION de votre clé. Un fichier ZIP n’est pas une image disque.')

    def _device_selected(self, _list, row):
        if not row or row not in self.device_rows: return
        dev = self.device_rows[row]
        try:
            self.selected_device_id = device_identity(dev['path'])
        except (OSError, ValueError) as exc:
            self.selected_device = None
            self.selected_source = None
            self.unmount_btn.set_sensitive(False)
            self.source_notice.set_label(str(exc))
            return
        self.selected_device = dev
        self.selected_source = dev['path']
        self.unmount_btn.set_sensitive(is_safe_usb_unmount(dev))
        self.fs_dropdown.set_selected(1 if (dev.get('fstype') or '').lower() in ('ext2','ext3','ext4') else 0)
        self.source_notice.set_label(f'Source sélectionnée : {dev["path"]}  ·  {human_size(dev.get("size"))}'
            + ('  — volume monté, démontage nécessaire.' if dev.get('mounted') else ''))

    def open_image_source(self):
        def done(path):
            try:
                if valid_source(path) != 'image': raise ValueError('Fichier image invalide.')
            except Exception as exc:
                self._dialog('Image incorrecte', str(exc)); return
            self.selected_source = path
            self.selected_device = None
            self.devices_list.unselect_all()
            self.unmount_btn.set_sensitive(False)
            self.source_notice.set_label('Image brute sélectionnée : ' + path)
        self._file_dialog('Ouvrir une image disque brute', Gtk.FileChooserAction.OPEN,
                          done, image_filter=True)

    def unmount_usb(self):
        dev = self.selected_device
        if not is_safe_usb_unmount(dev):
            self._dialog('Action indisponible','Choisissez une partition USB ordinaire actuellement montée.')
            return
        path = dev['path']
        def run_unmount():
            self.source_notice.set_label('Démontage en cours…')
            def task():
                match = next((x for x in flatten_devices(lsblk_data()) if x.get('path') == path), None)
                if not is_safe_usb_unmount(match): raise ValueError('État de la clé modifié ; démontage refusé.')
                cmd = subprocess.run(['udisksctl','unmount','-b',path],capture_output=True,
                                     text=True,timeout=90)
                if cmd.returncode: raise ValueError((cmd.stderr or cmd.stdout).strip())
                return True
            background(task, lambda _r,e: self._dialog('Démontage impossible',e) if e else self.refresh_devices())
        self._dialog('Démonter la clé USB',
            f'Démonter {path} sans débrancher la clé ?\nFermez d’abord les fichiers ouverts sur ce support.',
            confirm=run_unmount, confirm_text='Démonter')

    def _build_search(self):
        p = self._new_page('scan','Choisir votre recherche',
            'Commencez par les anciens noms, puis recherchez les signatures si nécessaire.')
        group = self._group('Méthode de recherche')
        self.method_buttons = {}
        for key, title, note in [
            ('metadata','Retrouver les noms d’origine','The Sleuth Kit · lister les fichiers supprimés avant de choisir quoi restaurer'),
            ('signature','Recherche approfondie','PhotoRec · rechercher les signatures des formats choisis'),
            ('advanced','Recherche avancée','Enchaîner les deux méthodes et consulter leurs résultats séparément')]:
            row = self._row(title, note)
            radio = Gtk.CheckButton()
            if self.method_buttons: radio.set_group(next(iter(self.method_buttons.values())))
            radio.set_active(key == 'metadata')
            row.add_suffix(radio)
            row.set_activatable_widget(radio)
            group.add(row)
            self.method_buttons[key] = radio
        p.append(group)
        cats = self._group('Types de fichiers', 'Cochez uniquement ce qui vous intéresse.')
        self.category_switches = {}
        for key, (name, _keys) in CATEGORIES.items():
            switch = Adw.SwitchRow()
            switch.set_title(name)
            switch.set_active(False)
            cats.add(switch)
            self.category_switches[key] = switch
        p.append(cats)
        everything = self._row('Tous les formats', 'Inclut les autres types de fichiers connus de PhotoRec')
        self.all_switch = Gtk.Switch()
        self.all_switch.set_active(True)
        self.all_switch.set_valign(Gtk.Align.CENTER)
        everything.add_suffix(self.all_switch)
        everything.set_activatable_widget(self.all_switch)
        cats.add(everything)
        self.all_switch.connect('notify::active',self._toggle_all)
        for switch in self.category_switches.values():
            switch.connect('notify::active', self._category_changed)
        details = Gtk.Expander(label='Choisir les familles PhotoRec une par une')
        fine = box()
        self.use_families = Gtk.CheckButton(label='Utiliser cette sélection pour la recherche par signatures')
        fine.append(self.use_families)
        self.families = {}
        special = {'riff':'RIFF (AVI, WAV, WebP)','mov':'MOV et MP4','zip':'ZIP, DOCX, ODT, EPUB, APK','a':'Archives Unix et DEB','doc':'Documents Office binaires et MSI','elf':'Exécutables ELF','mkv':'MKV et WebM','asf':'ASF, WMV et WMA'}
        keys = sorted({k for _, group in CATEGORIES.values() for k in group})
        grid = Gtk.Grid(column_spacing=8,row_spacing=4)
        for i,k in enumerate(keys):
            choice = Gtk.CheckButton(label=special.get(k,k.upper()))
            self.families[k] = choice
            grid.attach(choice, i%3, i//3, 1, 1)
        fine.append(grid)
        details.set_child(fine)
        p.append(details)
        options = self._group('Analyse et destination')
        mode_row = self._row('Zone à analyser', 'L’espace libre vise les données supprimées ; le volume entier peut en produire davantage.')
        self.mode_dropdown = Gtk.DropDown.new_from_strings(['Espace libre seulement','Tout le volume'])
        self.mode_dropdown.set_valign(Gtk.Align.CENTER)
        mode_row.add_suffix(self.mode_dropdown)
        options.add(mode_row)
        fs_row = self._row('Système de fichiers', 'Sélectionnez Linux ext2/3/4 uniquement si le support utilise ce format.')
        self.fs_dropdown = Gtk.DropDown.new_from_strings(['FAT / NTFS / exFAT', 'Linux ext2/3/4'])
        self.fs_dropdown.set_valign(Gtk.Align.CENTER)
        fs_row.add_suffix(self.fs_dropdown)
        options.add(fs_row)
        dest = self._row('Enregistrer sur un autre disque', str(self.destination) + ' (créé automatiquement si nécessaire)')
        dest.add_suffix(button('Dossier personnel', self.use_default_destination,
                               icon='folder-symbolic'))
        dest.add_suffix(button('Parcourir…', self.choose_destination, icon='folder-open-symbolic'))
        dest.add_suffix(button('Saisir le chemin…', self.choose_destination_path))
        options.add(dest)
        self.destination_row = dest
        p.append(options)
        p.append(self._notice('PhotoRec écrit les fichiers pendant l’analyse, contrairement à la recherche par noms.'))
        actions = box(Gtk.Orientation.HORIZONTAL, 12)
        actions.append(button('Retour', lambda:self.navigate('support'),icon='go-previous-symbolic'))
        grow=Gtk.Box();grow.set_hexpand(True);actions.append(grow)
        self.scan_btn = button('Lancer la recherche', self.start_scan, 'suggested-action', 'system-search-symbolic')
        actions.append(self.scan_btn)
        p.append(actions)

    def _toggle_all(self, _switch, _param):
        if self.all_switch.get_active():
            for switch in self.category_switches.values(): switch.set_active(False)

    def _category_changed(self, _switch, _param):
        if any(s.get_active() for s in self.category_switches.values()):
            self.all_switch.set_active(False)

    def use_default_destination(self):
        # This button bypasses GTK's folder portal if the system chooser fails.
        def done(path, error):
            if error:
                self._dialog('Dossier inaccessible', error)
                return
            self.destination = Path(path)
            self.destination_row.set_subtitle(str(path))
        source=self.selected_source
        def create():
            if source:
                safe_output(source,Path.home())
            return ensure_default_recovery_directory()
        background(create, done)

    def _assign_destination(self, path):
        try:
            folder = existing_destination(path)
        except ValueError as exc:
            self._dialog('Dossier inaccessible', str(exc))
            return
        self.destination = folder
        self.destination_row.set_subtitle(str(folder))
        self.status.set_label('Destination sélectionnée : ' + str(folder))

    def choose_destination(self):
        # The native file chooser uses the desktop portal. On some Ubuntu
        # installations this portal refuses to display a folder. The adjacent
        # 'Saisir le chemin' action avoids the portal entirely.
        self._file_dialog('Choisir un dossier sur un autre disque',
                          Gtk.FileChooserAction.SELECT_FOLDER, self._assign_destination)

    def choose_destination_path(self):
        """Fully graphical, portal-independent destination selector."""
        dlg = Adw.MessageDialog.new(self, 'Choisir un dossier',
            'Copiez le chemin du dossier depuis Fichiers (Ctrl+L), puis collez-le ici. '
            'Il doit déjà exister. « Dossier personnel » fonctionne sans cette étape.')
        entry = Gtk.Entry()
        entry.set_text(str(self.destination))
        entry.set_placeholder_text('/home/utilisateur/Récupérations')
        entry.set_hexpand(True)
        entry.set_activates_default(True)
        dlg.set_extra_child(entry)
        dlg.add_response('cancel', 'Annuler')
        dlg.add_response('choose', 'Utiliser ce dossier')
        dlg.set_default_response('choose')
        dlg.set_response_appearance('choose', Adw.ResponseAppearance.SUGGESTED)
        dlg.connect('response', lambda _d, r: self._assign_destination(entry.get_text())
                    if r == 'choose' else None)
        dlg.present()

    def selected_categories(self):
        return normalize_categories(['all'] if self.all_switch.get_active() else
                   [key for key, switch in self.category_switches.items() if switch.get_active()])

    def ensure_source(self):
        if not self.selected_source: raise ValueError('Choisissez d’abord votre clé ou partition dans « Supports ».')
        kind = valid_source(self.selected_source)
        if kind == 'device' and self.selected_device:
            dev = self.selected_device
            if dev.get('mounted') or dev.get('nested_mounts'):
                raise ValueError('Le support est monté : démontez-le avant de rechercher des fichiers.')
            if dev.get('type') == 'disk' and dev.get('has_children'):
                raise ValueError('Choisissez la partition de votre clé plutôt que le disque entier.')
            if dev.get('type') in ('lvm','crypt'):
                raise ValueError('Choisissez une partition ordinaire, pas un volume chiffré brut.')
        return kind

    def start_scan(self):
        if self.job or self._scan_verifying: return
        try:
            self.ensure_source()
            families = [k for k,v in self.families.items() if v.get_active()] if self.use_families.get_active() else None
            if families == [] and not self.method_buttons['metadata'].get_active():
                raise ValueError('Cochez les familles PhotoRec souhaitées.')
            cats = ['all'] if families and self.method_buttons['signature'].get_active() else self.selected_categories()
            source = self.selected_source
            dest = self.destination
            method = next(k for k,b in self.method_buttons.items() if b.get_active())
        except Exception as exc:
            self._dialog('Vérification nécessaire',str(exc)); return
        self._scan_verifying=True
        self.scan_btn.set_sensitive(False)
        self.status.set_label('Vérification de la source et de la destination…')
        def checked(_result,error):
            self._scan_verifying=False
            self.scan_btn.set_sensitive(True)
            if error:
                self._dialog('Destination non sûre',error)
                self.status.set_label('Prêt')
                return
            explanation = ('Vous pourrez choisir les fichiers à restaurer après la recherche.'
                          if method == 'metadata' else
                          'PhotoRec écrira directement les fichiers reconnus dans les catégories choisies.')
            if self.selected_device:
                explanation += '\nUne image complète de la partition sera conservée dans la destination. Prévoyez '+human_size(self.selected_device.get('size'))+' en plus des fichiers récupérés.'
            def run():
                try:
                    self.result_items=[]
                    self.result_mode=None
                    self.catalog=None
                    self.combined_box.set_visible(False)
                    output = dest / ('Recup-Studio-'+dt.datetime.now().strftime('%Y%m%d-%H%M%S')+'-'+uuid.uuid4().hex[:4])
                    if method != 'metadata': output.mkdir(mode=0o700)
                    self.result_source=source
                    self.result_base=str(output) if method!='metadata' else None
                    self.selected_ids.clear()
                    self.launch_job(method,source,str(output) if method!='metadata' else None,
                         categories=cats,families=families,mode='free' if self.mode_dropdown.get_selected()==0 else 'whole',
                         filesystem='ext' if self.fs_dropdown.get_selected()==1 else 'other')
                except Exception as exc:
                    self._dialog('Lancement impossible',str(exc))
            if source != self.selected_source:
                self.status.set_label('Le support a changé. Relancez la recherche.')
                return
            self._dialog('Confirmer l’analyse',
                f'Source : {source}\nDestination : {dest}\n\n{explanation}\n\nContinuer ?',
                confirm=run, confirm_text='Démarrer')
        def verify():
            if dest == Path.home() / 'Récupérations':
                safe_output(source,dest.parent)
                ensure_default_recovery_directory()
            if not dest.is_dir(): raise ValueError('Choisissez un dossier de destination déjà existant.')
            safe_output(source,dest)
            return True
        background(verify,checked)

    def _build_results(self):
        p = self._new_page('results','Fichiers retrouvés',
            'Parcourez les résultats et sélectionnez uniquement ce que vous souhaitez restaurer.',width=1180)
        searchbar = box(Gtk.Orientation.HORIZONTAL, 12)
        self.search_entry = Gtk.SearchEntry()
        self.search_entry.set_property('placeholder-text', 'Rechercher un nom ou une extension…')
        self.search_entry.set_hexpand(True)
        self.search_entry.connect('search-changed',self._search_changed)
        searchbar.append(self.search_entry)
        self.filter_menu = Gtk.DropDown.new_from_strings([name for name,_ in FILTERS])
        self.filter_menu.connect('notify::selected',lambda *_: self.render_results(reset=True))
        tools_row=box(Gtk.Orientation.HORIZONTAL, 12)
        tools_row.append(self.filter_menu)
        searchbar.append(button('Ouvrir un dossier…',self.pick_old_results, icon='folder-open-symbolic'))
        self.sort_menu = Gtk.DropDown.new_from_strings(['Ordre du moteur','Taille décroissante','Taille croissante'])
        self.sort_menu.connect('notify::selected',lambda *_: self.render_results(reset=True))
        tools_row.append(self.sort_menu)
        p.append(searchbar)
        p.append(tools_row)
        self.combined_box = box(Gtk.Orientation.HORIZONTAL, 10)
        self.combined_box.append(button('Voir les anciens noms',lambda:self.load_catalog(self.combined_catalog)))
        self.combined_box.append(button('Voir les signatures',lambda:self.load_photorec(self.combined_files)))
        self.combined_box.set_visible(False)
        p.append(self.combined_box)
        self.result_notice = label('Aucune recherche terminée.', 'dim-label', True)
        p.append(self.result_notice)
        columns = box(Gtk.Orientation.HORIZONTAL, 12)
        columns.set_vexpand(True)
        files_pane = box(spacing=0)
        files_pane.set_hexpand(True)
        files_pane.set_vexpand(True)
        self.file_list = Gtk.ListBox()
        self.file_list.set_selection_mode(Gtk.SelectionMode.NONE)
        self.file_list.add_css_class('boxed-list')
        self.file_list.connect('row-activated',self._item_activated)
        self.result_row_map = {}
        scroll = Gtk.ScrolledWindow()
        scroll.set_min_content_height(380)
        scroll.set_policy(Gtk.PolicyType.NEVER,Gtk.PolicyType.AUTOMATIC)
        scroll.set_child(self.file_list)
        files_pane.append(scroll)
        columns.append(files_pane)
        preview = box(spacing=11)
        preview.set_size_request(246, -1)
        preview.add_css_class('card')
        preview.set_margin_start(4)
        preview.set_margin_end(4)
        preview.set_margin_bottom(4)
        self.preview_title=label('Aperçu', 'heading', True)
        self.preview_title.set_margin_top(18)
        self.preview_title.set_margin_start(15)
        self.preview_title.set_margin_end(15)
        preview.append(self.preview_title)
        self.preview_picture = Gtk.Picture()
        self.preview_picture.set_content_fit(Gtk.ContentFit.CONTAIN)
        self.preview_picture.set_size_request(210, 180)
        self.preview_picture.set_can_shrink(True)
        preview.append(self.preview_picture)
        self.preview_info=label('Sélectionnez un fichier dans la liste.', 'dim-label',True)
        self.preview_info.set_margin_start(15)
        self.preview_info.set_margin_end(15)
        self.preview_info.set_margin_bottom(15)
        preview.append(self.preview_info)
        columns.append(preview)
        p.append(columns)
        pager=box(Gtk.Orientation.HORIZONTAL, 9)
        pager.append(button('← Précédents',lambda:self.move_page(-1)))
        self.page_notice=label('Page 1', 'dim-label')
        pager.append(self.page_notice)
        pager.append(button('Suivants →',lambda:self.move_page(1)))
        grow=Gtk.Box();grow.set_hexpand(True);pager.append(grow)
        pager.append(button('Tout sélectionner sur la page',self.select_page))
        p.append(pager)
        bottom=box(Gtk.Orientation.HORIZONTAL,10)
        bottom.append(button('Ouvrir le dossier',self.open_result_directory,icon='folder-open-symbolic'))
        grow=Gtk.Box();grow.set_hexpand(True);bottom.append(grow)
        self.restore_btn=button('Récupérer la sélection',self.restore_selected,'suggested-action')
        bottom.append(self.restore_btn)
        p.append(bottom)
        self._filtered = []
        self._debounce_id=0

    def _search_changed(self, _entry):
        if self._debounce_id: GLib.source_remove(self._debounce_id)
        self._debounce_id=GLib.timeout_add(250,self._finish_search)

    def _finish_search(self):
        self._debounce_id=0
        self.render_results(reset=True)
        return GLib.SOURCE_REMOVE

    def _item_activated(self,_list,row):
        record=self.result_row_map.get(row)
        if record: self.show_preview(record)

    def render_results(self, reset=False):
        if reset:self.page=0
        query=self.search_entry.get_text().strip().lower()
        cat=FILTERS[self.filter_menu.get_selected()][1]
        self._filtered=[r for r in self.result_items if (cat=='all' or r.get('category')==cat)
            and (not query or query in (r['name']+' '+r['path']).lower())]
        order = self.sort_menu.get_selected()
        if order:
            self._filtered.sort(key=lambda r:r.get('size',0), reverse=order==1)
        maxpage=max(0,(len(self._filtered)-1)//self.page_size)
        self.page=min(self.page,maxpage)
        portion=self._filtered[self.page*self.page_size:(self.page+1)*self.page_size]
        self.visible_records=portion
        self.result_row_map.clear()
        while (row := self.file_list.get_first_child()) is not None:
            self.file_list.remove(row)
        for record in portion:
            item=Gtk.ListBoxRow()
            line=box(Gtk.Orientation.HORIZONTAL,12)
            line.set_margin_top(8);line.set_margin_bottom(8)
            line.set_margin_start(12);line.set_margin_end(12)
            check=Gtk.CheckButton()
            check.set_active(record['key'] in self.selected_ids)
            check.connect('toggled',self._check_result,record)
            line.append(check)
            icon=Gtk.Image.new_from_icon_name('image-x-generic-symbolic' if record.get('category')=='images'
                else 'text-x-generic-symbolic')
            icon.set_pixel_size(20)
            line.append(icon)
            info=box(spacing=3)
            info.set_hexpand(True)
            filename=label(record['name'])
            filename.set_max_width_chars(55)
            filename.set_ellipsize(Pango.EllipsizeMode.END)
            info.append(filename)
            location=label(record['path'], 'dim-label')
            location.set_max_width_chars(68)
            location.set_ellipsize(Pango.EllipsizeMode.END)
            info.append(location)
            line.append(info)
            tag = label(CATEGORIES.get(record.get('category'),('Autre',))[0], 'dim-label')
            line.append(tag)
            line.append(label(human_size(record.get('size')), 'dim-label'))
            item.set_child(line)
            self.file_list.append(item)
            self.result_row_map[item]=record
        count=len(self.result_items)
        if self.result_mode=='metadata':
            self.result_notice.set_label(f'{count} entrées supprimées répertoriées · contenu non garanti. '
                'Sélectionnez les fichiers à restaurer.')
            self.restore_btn.set_label('Récupérer la sélection')
        elif self.result_mode=='signature':
            images=sum(1 for r in self.result_items if r['category']=='images')
            self.result_notice.set_label(f'{count} fichiers récupérés · {images} images. '
                'Fichiers présents dans le dossier de récupération.')
            self.restore_btn.set_label('Exporter la sélection…')
        else:
            self.result_notice.set_label('Aucune récupération chargée. Lancez une recherche.')
        self.page_notice.set_label(f'Page {self.page + 1} / {maxpage + 1} · {len(self._filtered)} résultat(s)')

    def _check_result(self, toggle, record):
        if toggle.get_active(): self.selected_ids.add(record['key'])
        else:self.selected_ids.discard(record['key'])
        self.show_preview(record)

    def select_page(self):
        for item in self.visible_records: self.selected_ids.add(item['key'])
        self.render_results()

    def move_page(self, delta):
        next_page=self.page+delta
        if 0<=next_page<=max(0,(len(self._filtered)-1)//self.page_size):
            self.page=next_page
            self.render_results()

    def show_preview(self, record):
        self._preview_serial += 1
        ticket = self._preview_serial
        self.preview_title.set_label(record['name'])
        self.preview_picture.set_paintable(None)
        if self.result_mode=='metadata':
            msg = 'Ancien chemin : '+record['path']+'\nRéférence : '+record['inode']
            if record.get('reallocated'): msg+='\nMétadonnées réattribuées : restauration déconseillée.'
            else:msg+='\nAperçu possible après restauration.'
            self.preview_info.set_label(msg)
            return
        self.preview_info.set_label('Fichier récupéré · '+human_size(record.get('size')))
        if record.get('category')!='images' or record.get('size',0)>30*1024*1024:return
        image_path=record['path']
        def task():
            return GdkPixbuf.Pixbuf.new_from_file_at_scale(image_path,208,190,True)
        def finished(pixbuf,error):
            if self._preview_serial!=ticket:return
            if error:
                self.preview_info.set_label('Aperçu indisponible : image probablement incomplète.')
            else:
                self.preview_picture.set_paintable(Gdk.Texture.new_for_pixbuf(pixbuf))
        background(task,finished)

    def load_catalog(self, path):
        self._loading=True
        self.result_notice.set_label('Chargement des anciens noms…')
        def task():
            out=[]
            with open(path,encoding='utf-8') as f:
                for i,line in enumerate(f):
                    r=json.loads(line)
                    r['key']=r['inode']+'|'+r['path']
                    out.append(r)
            return out
        def finished(rows,error):
            self._loading=False
            if error:self._dialog('Lecture impossible',error);return
            self.result_items=rows
            self.result_mode='metadata'
            self.catalog=Path(path)
            self.result_base=None
            self.selected_ids.clear()
            self.navigate('results')
            self.render_results(reset=True)
        background(task,finished)

    def load_photorec(self, folder):
        self._loading=True
        self.result_notice.set_label('Indexation des résultats…')
        def task():
            out=[]
            for current,dirs,files in os.walk(folder):
                dirs[:]=[name for name in dirs if not (Path(current)/name).is_symlink()]
                for name in files:
                    if name in ('report.xml','photorec.log'):continue
                    path=Path(current)/name
                    if not path.is_file() or path.is_symlink():continue
                    out.append({'name':name,'path':str(path),'key':str(path),
                                'category':category_for_name(name),'size':path.stat().st_size})
            return out
        def finished(rows,error):
            self._loading=False
            if error:self._dialog('Indexation impossible',error);return
            self.result_items=rows
            self.result_mode='signature'
            self.result_base=folder
            self.selected_ids.clear()
            self.navigate('results')
            self.render_results(reset=True)
        background(task,finished)

    def pick_old_results(self):
        if self.job:return
        def done(folder):
            self.combined_box.set_visible(False)
            self.result_source=None
            self.load_photorec(folder)
        self._file_dialog('Ouvrir un dossier de récupération',Gtk.FileChooserAction.SELECT_FOLDER,done)

    def open_result_directory(self):
        if not self.result_base:
            self._dialog('Dossier indisponible','Sélectionnez des fichiers à restaurer d’abord.')
            return
        subprocess.Popen(['xdg-open',self.result_base],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)

    def _build_image(self):
        p = self._new_page('image','Sauvegarder un disque',
            'Copier une partition via UDisks en lecture seule, ou dupliquer une image existante avec GNU ddrescue.')
        group = self._group('Image du support')
        self.image_source_row=self._row('Support source', 'Choisissez une partition dans « Supports ».')
        group.add(self.image_source_row)
        self.image_target_row=self._row('Fichier de destination', 'Aucun fichier sélectionné')
        self.image_target_row.add_suffix(button('Choisir…', self.choose_image_output))
        group.add(self.image_target_row)
        p.append(group)
        p.append(self._notice('Une image complète peut occuper autant d’espace que la clé ou le disque. Choisissez un autre disque physique.'))
        p.append(button('Créer l’image',self.start_image,'suggested-action','document-save-symbolic'))

    def choose_image_output(self):
        def done(path):
            self.image_output=path
            self.image_target_row.set_subtitle(path)
        self._file_dialog('Enregistrer une image brute',Gtk.FileChooserAction.SAVE,done,
                          suggested='sauvegarde-disque.img')

    def _build_help(self):
        p = self._new_page('help','Aide et sécurité',
            'Les bonnes pratiques pour récupérer des fichiers sans endommager les données restantes.')
        group=self._group('Avant de commencer')
        notes=[
            ('1 · Vérifiez la Corbeille', 'Ubuntu peut conserver les noms et les dossiers lors d’une suppression normale.'),
            ('2 · Ne réécrivez rien sur la clé', 'Évitez de copier ou installer quoi que ce soit sur le support concerné.'),
            ('3 · Démontez la partition', 'Sans débrancher la clé USB. Pour le disque système, utilisez une session Ubuntu Live.'),
            ('4 · Cherchez les noms d’origine', 'The Sleuth Kit peut retrouver les noms supprimés quand les métadonnées sont encore présentes.'),
            ('5 · Limitez les formats recherchés', 'PhotoRec ne conserve généralement pas les noms ni les anciens dossiers.'),
            ('6 · Récupération non garantie', 'TRIM, écrasement et corruption peuvent rendre certains fichiers irrécupérables.'),
        ]
        for title,detail in notes: group.add(self._row(title,detail))
        p.append(group)
        p.append(self._notice('Récup Studio travaille localement avec The Sleuth Kit, PhotoRec et GNU ddrescue.'))
        p.append(button('Afficher le diagnostic',self.open_diagnostic,
                        icon='dialog-information-symbolic'))

    def open_diagnostic(self):
        from launcher import diagnostic
        diagnostic()

    def launch_job(self, action, source, destination=None, **extra):
        if self.job:raise ValueError('Une opération est déjà en cours.')
        kind=valid_source(source)
        if kind == 'device':
            base = Path(destination).parent if action=='clone' else self.destination
            safe_output(source,base)
            job=base/('Recup-Session-'+uuid.uuid4().hex[:12])
        else:
            job=session_dir()/str(uuid.uuid4())
        job.mkdir(mode=0o700)
        config={'action':action,'source':source,**extra}
        if kind=='device':config['device_id']=self.selected_device_id
        if destination is not None:config['destination']=destination
        atomic_json(job/'config.json',config)
        atomic_json(job/'control.json',{'cancel':False})
        cmd=['/usr/bin/python3',str(WORKER),'--job',str(job)]
        self.proc=subprocess.Popen(cmd,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,
                                   stderr=subprocess.DEVNULL,start_new_session=True)
        self.job=job
        self.progress.set_visible(True)
        self.progress.set_fraction(0)
        self.spinner.start()
        self.status.set_label('Opération en cours…')
        self.stop_btn.set_sensitive(True)
        self.scan_btn.set_sensitive(False)

    def poll(self):
        if self.job:
            status=read_json(self.job/'status.json',{})
            if status:
                if status.get('percent') is None:
                    self.progress.pulse()
                else:
                    self.progress.set_fraction(status['percent']/100)
                self.status.set_label(str(status.get('message','Opération en cours…'))[:160])
                if status.get('state') in ('done','error','cancelled'):
                    previous=self.job
                    self.job=None
                    self.spinner.stop()
                    self.stop_btn.set_sensitive(False)
                    self.scan_btn.set_sensitive(True)
                    if status['state']=='error':
                        if (previous/'source.json').is_file() and (previous/'catalog.jsonl').is_file() and not status.get('metadata_error'):
                            self.load_catalog(previous/'catalog.jsonl')
                        self._dialog('Analyse impossible',
                           str(status.get('message','Erreur'))+'\nJournal : '+str(previous/'process.log'))
                    elif status['state']=='cancelled':
                        self._dialog('Opération interrompue',status.get('message','Arrêt effectué.'))
                    elif status.get('action')=='advanced':
                        self.combined_catalog=previous/'catalog.jsonl'
                        self.combined_files=status['result_path']
                        self.combined_box.set_visible(self.combined_catalog.exists() and not status.get('metadata_error'))
                        self.load_photorec(self.combined_files)
                        if status.get('metadata_error'):
                            self._dialog('Recherche par noms incomplète',status['metadata_error'])
                    elif status.get('action')=='metadata':
                        self.load_catalog(previous/'catalog.jsonl')
                    elif status.get('action') in ('signature','restore'):
                        if status.get('action')=='restore' and (not status.get('count') or status.get('blanks')):
                            self._dialog('Bilan de la restauration',status.get('message',''))
                        self.load_photorec(status.get('result_path',''))
                    elif status.get('action')=='clone':
                        self._dialog('Image créée',status.get('message','Terminé.'))
            if self.job and self.proc and self.proc.poll() is not None and not read_json(self.job/'status.json',{}).get('state') in ('done','error','cancelled'):
                self.spinner.stop()
                self.stop_btn.set_sensitive(False)
                self.scan_btn.set_sensitive(True)
                self.job=None
                self.status.set_label('Opération non démarrée')
                self._dialog('Autorisation ou moteur interrompu',
                    'Le moteur n’a pas démarré. Consultez le diagnostic et vérifiez l’autorisation Ubuntu.')
        self.progress.set_visible(bool(self.job))
        return GLib.SOURCE_CONTINUE

    def cancel(self):
        if not self.job:return
        def stop():
            atomic_json(self.job/'control.json',{'cancel':True})
            self.status.set_label('Arrêt demandé…')
        self._dialog('Arrêter l’opération',
            'Interrompre l’analyse ? Les fichiers déjà écrits seront conservés.',
            confirm=stop,confirm_text='Arrêter')

    def start_image(self):
        if self.job:return
        try:
            self.ensure_source()
            path=Path(self.image_output).expanduser()
            if not self.image_output or path.suffix.lower() not in ('.img','.dd','.raw') or not path.parent.is_dir():
                raise ValueError('Choisissez un fichier .img dans un dossier existant.')
            safe_output(self.selected_source,path.parent)
            if path.exists():
                raise ValueError('Le fichier existe déjà. Choisissez un autre nom.')
        except Exception as exc:
            self._dialog('Image disque',str(exc));return
        def run():
            try:self.launch_job('clone',self.selected_source,str(path))
            except Exception as exc:self._dialog('Création impossible',str(exc))
        self._dialog('Créer une image de disque',
            f'Source : {self.selected_source}\nDestination : {path}\n\nContinuer ?',
            confirm=run, confirm_text='Créer l’image')

    def restore_selected(self):
        if not self.selected_ids:
            self._dialog('Aucun fichier choisi','Cochez les fichiers à récupérer dans la liste.')
            return
        if self.job:return
        if self.result_mode=='metadata':
            src=self.result_source
            if not src or not self.catalog:
                self._dialog('Source introuvable','Choisissez de nouveau un support.');return
            dest=self.destination
            def checked(_result,error):
                if error:self._dialog('Destination non sûre',error);return
                def run():
                    target=dest/('Recup-Noms-'+dt.datetime.now().strftime('%Y%m%d-%H%M%S')+'-'+uuid.uuid4().hex[:4])
                    try:
                        target.mkdir(mode=0o700)
                        image=read_json(self.catalog.parent/'source.json',{})['path']
                        self.launch_job('restore',image,str(target),catalog=str(self.catalog),
                                        selected=sorted(self.selected_ids))
                        self.result_base=str(target)
                    except Exception as exc:self._dialog('Restauration impossible',str(exc))
                self._dialog('Restaurer les fichiers',
                    f'Essayer de restaurer {len(self.selected_ids)} fichier(s) vers :\n{dest}\n\n'
                    'Les anciens contenus peuvent être vides ou corrompus.',
                    confirm=run,confirm_text='Restaurer')
            background(lambda:safe_output(src,dest),checked)
            return
        if self.result_mode=='signature':
            def done(dst):
                chosen=[r for r in self.result_items if r['key'] in self.selected_ids]
                def task():
                    if self.result_source:safe_output(self.result_source,dst)
                    import hashlib
                    n=0
                    seen=set()
                    for row in chosen:
                        src=Path(row['path'])
                        if not src.is_file() or src.is_symlink():continue
                        hasher=hashlib.sha256()
                        with src.open('rb') as incoming:
                            for block in iter(lambda:incoming.read(1024*1024),b''):
                                hasher.update(block)
                        key=(src.stat().st_size,hasher.digest())
                        if key in seen:continue
                        seen.add(key)
                        target=Path(dst)/src.name
                        for i in range(10000):
                            if not target.exists():break
                            target=Path(dst)/(src.stem+'-'+str(i+1)+src.suffix)
                        with target.open('xb') as out, src.open('rb') as incoming:
                            shutil.copyfileobj(incoming,out)
                        n+=1
                    return n
                background(task,lambda n,e:self._dialog('Erreur de copie',e) if e else
                           self._dialog('Fichiers copiés',f'{n} fichier(s) exporté(s).'))
            self._file_dialog('Exporter les fichiers sélectionnés',Gtk.FileChooserAction.SELECT_FOLDER,done)

    def _on_close(self,*_args):
        if self.job:
            self._dialog('Opération en cours','Interrompez d’abord l’analyse avec « Arrêter ».')
            return True
        return False


class StudioApp(Adw.Application):
    def __init__(self):
        super().__init__(application_id='fr.recupstudio.app', flags=Gio.ApplicationFlags.FLAGS_NONE)
        self.window=None

    def do_activate(self):
        if not self.window:
            self.window=StudioWindow(self)
        self.window.present()
        try:
            from launcher import log_message
            log_message('Fenêtre GTK4/libadwaita affichée.')
        except Exception:
            pass


def main():
    # PyGObject signal exceptions otherwise disappear behind a launcher icon.
    def exception_handler(kind, error, tb):
        message = ''.join(traceback.format_exception(kind, error, tb))
        try:
            from launcher import log_message
            log_message('ERREUR INTERFACE GTK :\n'+message)
        except Exception:
            pass
        print(message, file=sys.stderr)
    sys.excepthook=exception_handler
    app = StudioApp()
    return app.run([sys.argv[0]])


if __name__=='__main__':
    raise SystemExit(main())
