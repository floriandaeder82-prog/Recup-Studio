# SPDX-License-Identifier: GPL-3.0-or-later
"""Disk/source inventory and safety rules used by the frontend and worker."""
from __future__ import annotations
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import tempfile

APP_ID = 'fr.recupstudio.app'
VERSION = '0.4.0'
DEFAULT_STATE = Path.home() / '.local' / 'state' / 'recupstudio'


def human_size(count):
    if count is None:
        return '—'
    n = float(count)
    for unit in ('o', 'Kio', 'Mio', 'Gio', 'Tio', 'Pio'):
        if n < 1024 or unit == 'Pio':
            return (f'{n:.0f}' if unit == 'o' else f'{n:.1f}') + ' ' + unit
        n /= 1024


def lsblk_data():
    cmd = ['lsblk', '--json', '--bytes', '-o',
           'NAME,PATH,TYPE,SIZE,FSTYPE,MODEL,MOUNTPOINTS,PKNAME,RO,TRAN,LABEL,RM,HOTPLUG']
    p = subprocess.run(cmd, capture_output=True, text=True, timeout=12, check=True)
    return json.loads(p.stdout).get('blockdevices', [])


def _true_flag(value):
    return value is True or value == 1 or value == '1'


def flatten_devices(items):
    """Flatten lsblk, preserving mount points and inherited USB indicators."""
    flat = []

    def find_mounts(node):
        locations = [x for x in (node.get('mountpoints') or []) if x]
        for child in node.get('children', []):
            locations.extend(find_mounts(child))
        return locations

    def visit(node, parent=None, root=None):
        origin = root if root is not None else node
        current = dict(node)
        current.pop('children', None)
        current['parent_path'] = parent
        current['root_path'] = origin.get('path')
        current['mounted'] = bool([x for x in (node.get('mountpoints') or []) if x])
        current['nested_mounts'] = find_mounts(node)
        current['transport'] = (origin.get('tran') or '').lower()
        current['external'] = (
            current['transport'] == 'usb' or
            _true_flag(origin.get('rm')) or _true_flag(origin.get('hotplug'))
        )
        current['device_model'] = origin.get('model') or ''
        current['has_children'] = bool(node.get('children'))
        flat.append(current)
        for child in node.get('children', []):
            visit(child, node.get('path'), origin)

    for item in items:
        visit(item)
    return flat


def external_sources(devices):
    """Choose filesystem-bearing removable volumes, with whole-disk fallback."""
    selected = []
    for dev in devices:
        if not dev.get('external') or not dev.get('path'):
            continue
        if dev.get('type') == 'part':
            selected.append(dev)
        elif dev.get('type') == 'disk' and not dev.get('has_children'):
            selected.append(dev)
    return selected


def is_safe_usb_unmount(dev):
    """Only unmount ordinary auto-mounted USB volumes, never system volumes.

    Deliberately refuse unusual custom mounts and live-boot volumes. No force
    unmount, no drive power-off, no automatic write operations are performed.
    """
    if not dev or dev.get('type') not in ('part', 'disk') or not dev.get('external'):
        return False
    if (dev.get('fstype') or '').lower() in ('crypto_luks', 'lvm2_member', 'swap'):
        return False
    if not dev.get('mounted') or dev.get('has_children'):
        return False
    mounts = [x for x in (dev.get('mountpoints') or []) if x]
    if not mounts:
        return False
    return all(m.startswith(('/media/', '/run/media/')) for m in mounts)


def external_label(dev):
    name = (dev.get('label') or dev.get('device_model') or 'Sans nom').strip()
    name = ' '.join(name.split())[:68]
    path = dev.get('path') or '—'
    state = 'monté' if dev.get('mounted') else 'non monté'
    return f'{name} · {human_size(dev.get("size"))} · {path} · {state}'


def valid_source(path):
    """Accept only a real block device or a regular disk image."""
    if not isinstance(path, str) or not os.path.isabs(path):
        raise ValueError('La source doit être un chemin absolu.')
    st = os.stat(path)
    if stat.S_ISBLK(st.st_mode):
        return 'device'
    if stat.S_ISREG(st.st_mode):
        suffix = Path(path).suffix.lower()
        if suffix not in ('.img', '.dd', '.raw', '.bin'):
            raise ValueError(
                'Ce fichier n’est pas une image disque prise en charge. '
                'Les archives ZIP et les fichiers présents sur une clé USB ne '
                'permettent pas de rechercher ses fichiers supprimés. '
                'Pour analyser la clé entière, choisissez sa partition '
                '(par exemple /dev/sdb1) dans « Clé USB ou disque externe ». '
                'Seuls les fichiers .img, .dd, .raw et .bin sont acceptés ici.')
        # Also reject common archive signatures, even if an archive was
        # mistakenly renamed to .img or .raw. This is validation, not a
        # promise that every similarly named file contains a disk image.
        try:
            with open(path, 'rb') as handle:
                signature = handle.read(8)
        except OSError as exc:
            raise ValueError('Impossible de lire l’image disque sélectionnée.') from exc
        if signature.startswith((b'PK\x03\x04', b'PK\x05\x06', b'PK\x07\x08',
                                 b'7z\xbc\xaf\x27\x1c', b'Rar!\x1a\x07', b'\x1f\x8b')):
            raise ValueError('Cette source est une archive compressée, et non une image brute '
                             'de disque. Sélectionnez la clé USB dans la liste des périphériques.')
        if st.st_size == 0:
            raise ValueError('Le fichier image est vide.')
        return 'image'
    raise ValueError('La source doit être un périphérique ou un fichier image ordinaire.')


def device_root(path):
    """Map a partition /dev/mapper/... to its underlying physical disks."""
    st = os.stat(path)
    if not stat.S_ISBLK(st.st_mode):
        raise ValueError('Support physique non identifiable.')
    node = Path(f'/sys/dev/block/{os.major(st.st_rdev)}:{os.minor(st.st_rdev)}').resolve(strict=True)
    def leaves(item):
        if (item / 'partition').exists():
            return leaves(item.parent)
        slaves = list((item / 'slaves').iterdir())
        if slaves:
            return set().union(*(leaves(x.resolve(strict=True)) for x in slaves))
        if '/virtual/' in str(item) or not (item / 'device').exists():
            raise ValueError('Topologie physique non vérifiable.')
        return {item}
    return leaves(node)


def mounted_sources(source):
    """Return mounted paths on source and its descendants."""
    real = os.path.realpath(source)
    for dev in flatten_devices(lsblk_data()):
        if os.path.realpath(dev.get('path') or '') == real:
            return dev.get('nested_mounts', [])
    # Do not assume that an unidentified block device is unmounted.
    raise ValueError('Impossible de vérifier si ce périphérique est monté. Analyse refusée.')


def destination_on_source_disk(source, destination_dir):
    """Return True/False/None when device identity is inconclusive."""
    if valid_source(source) != 'device':
        return False
    try:
        proc = subprocess.run(['findmnt', '-n', '-o', 'SOURCE,FSTYPE', '-T', str(destination_dir)],
                              text=True, capture_output=True, timeout=8)
        if proc.returncode:
            return None
        mount_source, fs = proc.stdout.strip().splitlines()[0].rsplit(None, 1)
        if fs not in ('ext2','ext3','ext4','xfs','vfat','exfat','ntfs','ntfs3','fuseblk'):
            return None
        # findmnt may append an internal btrfs subvolume, e.g. /dev/sda2[/@].
        mount_source = mount_source.split('[', 1)[0]
        if not mount_source.startswith('/dev/'):
            return None
        return bool(device_root(source) & device_root(mount_source))
    except (ValueError, OSError, IndexError, subprocess.TimeoutExpired):
        return None


def safe_output(source, directory, *, require_different=True):
    """Conservative validation. Never allow writes onto a source block disk."""
    src_type = valid_source(source)
    dst = Path(directory).expanduser().resolve(strict=True)
    if not dst.is_dir():
        raise ValueError('Le dossier de destination est introuvable.')
    if not os.access(dst, os.W_OK):
        raise ValueError('Le dossier de destination n’est pas accessible en écriture.')
    if src_type == 'device':
        if mounted_sources(source):
            raise ValueError('Ce périphérique contient une partition montée. '
                             'Démontez-la d’abord ; pour le disque système, '
                             'démarrez Ubuntu depuis une clé USB (« Essayer Ubuntu »).')
        comparison = destination_on_source_disk(source, dst)
        if require_different and comparison is not False:
            raise ValueError('Choisissez un autre disque physique pour enregistrer les '
                             'résultats. Impossible de vérifier une destination sûre '
                             'sur un disque différent.')
    else:
        image = Path(source).resolve()
        if str(dst) == str(image) or image == dst:
            raise ValueError('La destination doit être un dossier, pas l’image source.')
    return dst



def existing_destination(path):
    """Validate a folder selected by the GUI without creating an arbitrary path."""
    if not isinstance(path, (str, os.PathLike)) or not str(path).strip():
        raise ValueError('Indiquez un dossier de destination.')
    target = Path(str(path).strip()).expanduser()
    if not target.is_absolute():
        raise ValueError('Indiquez le chemin complet du dossier, commençant par « / ».')
    try:
        target = target.resolve(strict=True)
    except (OSError, RuntimeError) as exc:
        raise ValueError('Ce dossier est introuvable ou inaccessible.') from exc
    if not target.is_dir():
        raise ValueError('Ce chemin ne désigne pas un dossier.')
    if not os.access(target, os.W_OK):
        raise ValueError('Vous n’avez pas le droit d’écrire dans ce dossier.')
    return target


def ensure_default_recovery_directory(home=None):
    """Create the opt-in personal recovery folder; source-disk check remains mandatory.

    This helper never creates folders on an arbitrary user-selected path.
    """
    base = Path(home) if home is not None else Path.home()
    target = base / 'Récupérations'
    try:
        target.mkdir(mode=0o700, exist_ok=True)
    except OSError as exc:
        raise ValueError(f'Impossible de créer le dossier Récupérations : {exc}') from exc
    if not target.is_dir():
        raise ValueError('Récupérations existe mais n’est pas un dossier.')
    return target


def session_dir():
    directory = DEFAULT_STATE / 'jobs'
    directory.mkdir(parents=True, exist_ok=True, mode=0o700)
    return directory


def atomic_json(path, data, *, owner_uid=None):
    """Write JSON atomically without following a predictable temporary symlink.

    A privileged worker can set owner_uid to make its status readable by the
    authenticated desktop user. Both temporary and final files have mode 0600.
    """
    p = Path(path)
    fd, name = tempfile.mkstemp(prefix='.' + p.name + '-', suffix='.tmp', dir=p.parent)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as file:
            os.fchmod(file.fileno(), 0o600)
            if owner_uid is not None and os.geteuid() == 0:
                os.fchown(file.fileno(), owner_uid, -1)
            json.dump(data, file, ensure_ascii=False, indent=2)
            file.flush()
            os.fsync(file.fileno())
        os.replace(name, p)
    finally:
        if os.path.exists(name):
            os.unlink(name)


def read_json(path, default=None):
    """Read a small JSON file, refusing symlinks and oversized data."""
    fd = None
    try:
        flags = os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0)
        fd = os.open(os.fspath(path), flags)
        if os.fstat(fd).st_size > 8 * 1024 * 1024:
            return default
        with os.fdopen(fd, 'r', encoding='utf-8') as file:
            fd = None
            return json.load(file)
    except (OSError, ValueError, UnicodeError, json.JSONDecodeError):
        return default
    finally:
        if fd is not None:
            os.close(fd)

def device_identity(path):
    """Le numéro de séquence change quand le noyau réattribue un nom de disque."""
    st = os.stat(path)
    if not stat.S_ISBLK(st.st_mode):
        raise ValueError('Le périphérique a disparu.')
    node = Path(f'/sys/dev/block/{os.major(st.st_rdev)}:{os.minor(st.st_rdev)}').resolve(strict=True)
    disk = node.parent if (node/'partition').exists() else node
    try:
        return [st.st_rdev, int((disk/'diskseq').read_text()), int((node/'size').read_text())]
    except (OSError,ValueError) as exc:
        raise ValueError('Impossible de vérifier l’identité du disque.') from exc
