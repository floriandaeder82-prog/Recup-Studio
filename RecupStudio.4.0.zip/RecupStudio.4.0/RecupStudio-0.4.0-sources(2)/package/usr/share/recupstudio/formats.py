# SPDX-License-Identifier: GPL-3.0-or-later
"""Documented PhotoRec file-family keys and UI category classification.

PhotoRec groups many extensions into a single family (mov covers MP4-like
containers; zip covers OOXML as well as archives). The UI spells this out.
"""
from __future__ import annotations
from pathlib import PurePath
import re

CATEGORIES = {
    'images': ('Photos et images', ('jpg', 'png', 'gif', 'bmp', 'tif', 'psd', 'riff')),
    'videos': ('Vidéos', ('mov', 'mkv', 'mpg', 'riff', 'asf')),
    'audio': ('Musique et audio', ('mp3', 'ogg', 'flac', 'riff', 'asf', 'aif')),
    'documents': ('Documents et PDF', ('pdf', 'doc', 'txt', 'zip')),
    'software': ('Logiciels et installateurs', ('exe', 'a', 'elf', 'doc', 'zip')),
    'archives': ('Archives et fichiers compressés', ('zip', '7z', 'rar', 'tar', 'gz', 'bz2')),
}

EXTENSIONS = {
    'images': {'.jpg','.jpeg','.png','.gif','.bmp','.tif','.tiff','.webp','.heic','.heif','.svg','.psd','.cr2','.nef','.avif'},
    'videos': {'.mp4','.mov','.avi','.mkv','.mpg','.mpeg','.wmv','.webm','.3gp','.flv'},
    'audio': {'.mp3','.ogg','.flac','.wav','.aac','.m4a','.aif','.wma'},
    'documents': {'.pdf','.doc','.docx','.odt','.ods','.xlsx','.xls','.ppt','.pptx','.txt','.rtf','.csv','.md','.epub'},
    'software': {'.deb','.rpm','.exe','.msi','.apk','.appimage','.sh','.bin'},
    'archives': {'.zip','.7z','.rar','.tar','.gz','.bz2','.xz','.tgz','.zst'},
}

RE_FLS = re.compile(r'^\s*\+*\s*([a-zA-Z\-]/[a-zA-Z\-])\s+\*\s+(\d+(?:-\d+){0,2})(\(realloc\))?:\s*(.+?)\s*$')
RE_INODE = re.compile(r'^\d+(?:-\d+){0,2}$')


def normalize_categories(selected):
    if not isinstance(selected, (list, tuple)):
        raise ValueError('Choix des catégories invalide.')
    if 'all' in selected:
        return ['all']
    out = list(dict.fromkeys(selected))
    if not out or any(x not in CATEGORIES for x in out):
        raise ValueError('Cochez au moins une catégorie de fichiers.')
    return out


def photorec_options(selected, families=None):
    """Return PhotoRec's documented fileopt command tokens, as a list."""
    selected = normalize_categories(selected)
    if families is not None:
        allowed = {k for _, group in CATEGORIES.values() for k in group}
        if not families or not isinstance(families,list) or not set(families)<=allowed:
            raise ValueError('Sélectionnez au moins une famille de signatures.')
        keys=sorted(set(families))
    elif selected == ['all']:
        return ['fileopt','everything','enable']
    else:
        keys = sorted({key for category in selected for key in CATEGORIES[category][1]})
    tokens = ['fileopt','everything','disable']
    for key in keys:
        tokens.extend((key, 'enable'))
    return tokens


def category_for_name(name):
    suffix = PurePath(name).suffix.lower()
    for k, extensions in EXTENSIONS.items():
        if suffix in extensions:
            return k
    return 'other'


def category_matches(name, categories):
    categories = normalize_categories(categories)
    return categories == ['all'] or category_for_name(name) in categories


def parse_fls(line):
    """Parse one Sleuth Kit fls -r -d -p record, never trust its path."""
    fields = line.rstrip('\n').rsplit('\t', 7)
    if len(fields) != 8 or not fields[-3].isdigit():
        return None
    match = RE_FLS.match(fields[0])
    if not match:
        return None
    kind, inode, realloc, text = match.groups()
    if kind[0].lower() != 'r' and kind != '-/r':
        return None
    # A deleted directory's contents may be prefixed with a path, and may
    # contain colons/spaces. Ignore TSK's synthetic entries.
    path = text.rstrip('/')
    if not path or path.split('/')[-1] in ('.', '..'):
        return None
    name = path.rsplit('/', 1)[-1]
    return {'inode': inode, 'name': name, 'path': path,
            'size': int(fields[-3]), 'category': category_for_name(name), 'reallocated': bool(realloc)}


def safe_filename(name):
    """Flatten untrusted filesystem names; no path traversal or control chars."""
    basename = str(name).replace('\\', '/').split('/')[-1]
    basename = ''.join(c if 32 <= ord(c) < 127 or ord(c) >= 160 else '_' for c in basename)
    basename = basename.strip(' .')[:180]
    return basename if basename not in ('', '.', '..') else 'fichier_recupere'
