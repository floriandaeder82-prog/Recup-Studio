# SPDX-License-Identifier: GPL-3.0-or-later
"""Acquisition d'une partition sans exécuter l'application comme administrateur."""
import array
import fcntl
import os
from pathlib import Path
import stat
import shutil

def open_volume(source):
    from gi.repository import Gio, GLib
    bus = Gio.bus_get_sync(Gio.BusType.SYSTEM, None)
    service = 'org.freedesktop.UDisks2'
    root = '/org/freedesktop/UDisks2'
    objects = bus.call_sync(service, root, 'org.freedesktop.DBus.ObjectManager',
                            'GetManagedObjects', None, None, 0, 15000, None).unpack()[0]
    dev = os.stat(source).st_rdev
    for path, interfaces in objects.items():
        block = interfaces.get(service + '.Block', {})
        if block.get('DeviceNumber') == dev:
            options = {'flags': GLib.Variant('i', os.O_EXCL)}
            reply, descriptors = bus.call_with_unix_fd_list_sync(
                service, path, service + '.Block', 'OpenDevice',
                GLib.Variant('(sa{sv})', ('r', options)), GLib.VariantType.new('(h)'),
                Gio.DBusCallFlags.ALLOW_INTERACTIVE_AUTHORIZATION, 120000, None, None)
            fd = descriptors.get(reply.unpack()[0])
            info = os.fstat(fd)
            if stat.S_ISBLK(info.st_mode) and info.st_rdev == dev:
                return fd
            os.close(fd)
            break
    raise ValueError('La partition a changé ou UDisks ne la reconnaît plus.')

def acquire(source, target, cancelled, progress):
    with os.fdopen(open_volume(source), 'rb', buffering=0) as disk:
        length = array.array('Q', [0])
        fcntl.ioctl(disk.fileno(), 0x80081272, length, True)  # BLKGETSIZE64
        size = length[0]
        if not size or shutil.disk_usage(target.parent).free < size:
            raise ValueError('Espace insuffisant pour conserver une image complète de la partition.')
        written = 0
        with target.open('xb') as out:
            try:
                previous = -1
                while written < size:
                    if cancelled():
                        raise InterruptedError('Copie interrompue.')
                    chunk = disk.read(min(size-written, 4*1024*1024))
                    if not chunk:
                        raise OSError('La lecture du support a pris fin prématurément.')
                    out.write(chunk)
                    written += len(chunk)
                    percent = written * 100 // size
                    if percent != previous:
                        progress(percent)
                        previous = percent
                out.flush()
                os.fsync(out.fileno())
            except BaseException:
                target.unlink(missing_ok=True)
                raise
