#!/usr/bin/python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Isolated worker for PhotoRec, The Sleuth Kit, and GNU ddrescue.

Called via graphical polkit authentication only when opening block devices.
No shell execution, no arbitrary command or overwrite operation.
"""
from __future__ import annotations
import argparse
import json
import os
from pathlib import Path
import shutil
import signal
import stat
import subprocess
import sys
import threading
import time

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import (atomic_json, read_json, safe_output, valid_source,
                    mounted_sources, device_identity)
from formats import (normalize_categories, photorec_options, parse_fls,
                     safe_filename, RE_INODE, category_matches)


def check_job(folder):
    folder = Path(folder)
    if not folder.is_absolute() or not folder.is_dir() or folder.is_symlink():
        raise ValueError('Dossier de travail non fiable.')
    uid = folder.stat().st_uid
    if os.geteuid() == 0:
        if str(uid) != os.environ.get('PKEXEC_UID'):
            raise ValueError('Authentification de l’utilisateur non vérifiée.')
    elif os.geteuid() != uid:
        raise ValueError('Utilisateur propriétaire incorrect.')
    config = folder / 'config.json'
    if config.is_symlink() or not config.is_file() or config.stat().st_uid != uid:
        raise ValueError('Configuration non fiable.')
    data = read_json(config)
    if not isinstance(data, dict) or data.get('action') not in ('metadata','signature','advanced','restore','clone'):
        raise ValueError('Action invalide.')
    if not isinstance(data.get('source'), str):
        raise ValueError('Source invalide.')
    return folder, data, uid


def emit_status(folder, **values):
    """Status files must remain readable by the desktop user after pkexec."""
    old = read_json(folder / 'status.json', {})
    if not isinstance(old, dict):
        old = {}
    old.update(values)
    atomic_json(folder / 'status.json', old, owner_uid=folder.stat().st_uid)


def open_job_log(folder):
    """Open the engine log without following a symlink with elevated privileges."""
    uid = folder.stat().st_uid
    flags = os.O_WRONLY | os.O_APPEND | os.O_CREAT | getattr(os, 'O_NOFOLLOW', 0)
    fd = os.open(folder / 'process.log', flags, 0o600)
    try:
        st = os.fstat(fd)
        if not stat.S_ISREG(st.st_mode) or st.st_nlink != 1:
            raise ValueError('Journal de récupération non fiable.')
        if os.geteuid() == 0 and st.st_uid == 0:
            os.fchown(fd, uid, -1)
            st = os.fstat(fd)
        if not stat.S_ISREG(st.st_mode) or st.st_uid != uid or st.st_nlink != 1:
            raise ValueError('Journal de récupération non fiable.')
        return os.fdopen(fd, 'ab', buffering=0)
    except BaseException:
        os.close(fd)
        raise


def cancelled(folder):
    return read_json(folder / 'control.json', {}).get('cancel') is True


def create_as_user(path, uid, *, mode=0o600):
    """Create an output as the calling user, never as root (exclusive/no-follow)."""
    return os.open(str(path), os.O_CREAT | os.O_EXCL | os.O_WRONLY | os.O_NOFOLLOW, mode)


def unique_user_output(directory, filename, uid):
    safe_name = safe_filename(filename)
    stem, suffix = os.path.splitext(safe_name)
    for i in range(10000):
        candidate = directory / (safe_name if i == 0 else f'{stem}-{i}{suffix}')
        try:
            fd = create_as_user(candidate, uid)
            return candidate, fd
        except FileExistsError:
            continue
    raise ValueError('Trop de fichiers portant le même nom.')


def run_process(folder, args, *, output=None, progress_dir=None):
    """Run one executable without shell; stop its process group if requested."""
    with open_job_log(folder) as log:
        proc = subprocess.Popen(args, stdin=subprocess.DEVNULL,
            stdout=(output if output is not None else log), stderr=log,
            cwd=str(folder), start_new_session=True)
        last_count = time.monotonic()
        while proc.poll() is None:
            if progress_dir and time.monotonic()-last_count >= 4:
                last_count=time.monotonic()
                n=count_files(progress_dir)
                emit_status(folder,count=n,message=f'Analyse en cours · {n} fichier(s) retrouvés…')
            if cancelled(folder):
                os.killpg(proc.pid, signal.SIGTERM)
                try:
                    proc.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    os.killpg(proc.pid, signal.SIGKILL)
                    proc.wait(timeout=3)
                return 'cancelled'
            time.sleep(0.35)
        return proc.returncode


def photorec_script(source_kind, source, fs, mode, categories, families=None):
    if fs not in ('ext', 'other') or mode not in ('free', 'whole'):
        raise ValueError('Options PhotoRec incorrectes.')
    script = []
    if source_kind == 'device':
        lines = subprocess.run(['lsblk', '-n', '-o','TYPE,NAME', source],
            capture_output=True, text=True, check=True, timeout=10).stdout.splitlines()
        if not lines:
            raise ValueError('Périphérique inconnu.')
        if lines[0].split()[0] == 'disk' and len(lines) > 1:
            raise ValueError('Sélectionnez une partition et non un disque contenant plusieurs partitions.')
    script.append('partition_none')
    if fs == 'ext':
        script += ['options','mode_ext2']
    script += photorec_options(categories, families)
    script += ['freespace' if mode == 'free' else 'wholespace', 'search']
    return ','.join(script)


def scan_metadata(folder, data, uid, combined=False):
    tool = shutil.which('fls')
    if not tool:
        raise ValueError('The Sleuth Kit est absent : installez le paquet « sleuthkit ».')
    source = data['source']
    categories = normalize_categories(data.get('categories', ['all']))
    catalog = folder / 'catalog.jsonl'
    emit_status(folder, state='running', action='metadata', percent=None, message='Recherche des noms de fichiers supprimés…', count=0)
    # Give the catalog file to the real user, never create it as root.
    fd = create_as_user(catalog, uid)
    n = 0
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as writer, open_job_log(folder) as log:
            proc = subprocess.Popen([tool,'-r','-d','-p','-l','-i','raw',source], stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE, stderr=log, text=True, errors='replace',
                bufsize=1, start_new_session=True)
            watcher_stop=threading.Event()
            def cancel_watcher():
                while not watcher_stop.wait(0.5):
                    if cancelled(folder) and proc.poll() is None:
                        try: os.killpg(proc.pid, signal.SIGTERM)
                        except ProcessLookupError: pass
                        return
            watcher=threading.Thread(target=cancel_watcher,daemon=True)
            watcher.start()
            try:
                for line in proc.stdout:
                    if cancelled(folder):
                        os.killpg(proc.pid, signal.SIGTERM)
                        proc.wait(timeout=6)
                        emit_status(folder, state='cancelled', message='Recherche interrompue.', count=n)
                        return
                    entry = parse_fls(line)
                    if entry and category_matches(entry['name'], categories):
                        writer.write(json.dumps(entry, ensure_ascii=False)+'\n')
                        n += 1
                        if n % 100 == 0:
                            emit_status(folder, count=n, message=f'{n} entrées supprimées répertoriées…')
                code = proc.wait(timeout=10)
            finally:
                watcher_stop.set()
                if proc.poll() is None:
                    proc.kill()
                    proc.wait()
        if cancelled(folder):
            emit_status(folder,state='cancelled',message='Recherche interrompue.',count=n,finished=time.time())
            return
        if code != 0:
            raise ValueError('Impossible de lire les métadonnées : système de fichiers non pris en charge, '
                             'disque complet au lieu d’une partition, ou erreur de lecture. Consultez le journal.')
        emit_status(folder, state='running' if combined else 'done', count=n, result_path=str(catalog),
                    message=(f'{n} fichier(s) supprimé(s) répertorié(s). Sélectionnez-les dans Résultats.'
                             if n else 'Aucun ancien nom trouvé. Essayez PhotoRec en recherche approfondie.'),
                    finished=time.time())
    except Exception:
        raise


def restore_metadata(folder, data, uid):
    source = data['source']
    destination = Path(data['destination']).resolve(strict=True)
    safe_output(source, destination)
    catalog_path = Path(data['catalog'])
    # The catalog must be produced in Récup Studio's private job directory.
    # Root's home differs from the authenticated user's home. Use sibling job
    # directories instead, and require the real user's ownership.
    if catalog_path.name != 'catalog.jsonl' or catalog_path.is_symlink() or catalog_path.stat().st_uid != uid:
        raise ValueError('Catalogue non fiable.')
    wanted = data.get('selected')
    if not isinstance(wanted, list) or not wanted:
        raise ValueError('Sélectionnez les fichiers à récupérer.')
    keys = set(wanted)
    matches = []
    for line in catalog_path.open(encoding='utf-8'):
        record = json.loads(line)
        if record['inode']+'|'+record['path'] in keys:
            if not RE_INODE.fullmatch(record['inode']):
                continue
            matches.append(record)
    if not matches:
        raise ValueError('Aucun fichier sélectionné ne figure dans le catalogue.')
    tool = shutil.which('icat')
    if not tool:
        raise ValueError('Le programme icat (Sleuth Kit) est absent.')
    good, bad, blanks = 0, 0, 0
    emit_status(folder, state='running', action='restore', count=0,
                message=f'Restauration de {len(matches)} fichier(s) sélectionné(s)…')
    for record in matches:
        if cancelled(folder):
            emit_status(folder, state='cancelled', count=good, message='Restauration interrompue.')
            return
        # Files with reallocated metadata must not be presented as definitely recoverable.
        if record.get('reallocated'):
            bad += 1
            continue
        parent = destination
        for part in Path(record['path']).parts[:-1]:
            if part in ('/', '.', '..'):
                raise ValueError('Chemin non fiable dans le catalogue.')
            parent = parent / safe_filename(part)
            if parent.is_symlink():
                raise ValueError('Lien symbolique refusé.')
            parent.mkdir(mode=0o700, exist_ok=True)
        file, fd = unique_user_output(parent, record['name'], uid)
        try:
            with os.fdopen(fd, 'wb') as output:
                result = run_process(folder, [tool, '-i', 'raw', '-r', source, record['inode']], output=output)
            if result == 0 and record.get('size', 0) > 0 and file.stat().st_size == record['size']:
                good += 1
                with file.open('rb') as restored:
                    if not any(chunk.strip(b'\0') for chunk in iter(lambda:restored.read(1024*1024),b'')):
                        blanks += 1
            else:
                file.unlink(missing_ok=True)
                bad += 1
        except Exception:
            file.unlink(missing_ok=True)
            bad += 1
        if cancelled(folder):
            raise InterruptedError('Restauration interrompue.')
        emit_status(folder, count=good, message=f'{good} fichier(s) restauré(s), {bad} échec(s)…')
    emit_status(folder, state='done', count=good, blanks=blanks, finished=time.time(), result_path=str(destination),
        message=f'{good} fichier(s) restauré(s). {bad} non récupérable(s) ou en échec. {blanks} fichier(s) entièrement à zéro. Vérifiez leur contenu.')


def count_files(folder):
    n = 0
    for root, dirs, files in os.walk(folder):
        n += sum(name not in ('report.xml','photorec.log') for name in files)
    return n


def run_signature(folder, data, uid, combined=False):
    source = data['source']
    source_kind = valid_source(source)
    output = Path(data['destination']).resolve(strict=True)
    safe_output(source, output)
    if output.stat().st_uid != uid:
        raise ValueError('La destination doit vous appartenir.')
    tool = shutil.which('photorec')
    if not tool:
        raise ValueError('Le moteur PhotoRec est absent.')
    probe = subprocess.run(['blkid','-p','-o','export',source],capture_output=True,text=True,timeout=30)
    props = dict(line.split('=',1) for line in probe.stdout.splitlines() if '=' in line)
    fs_type = props.get('TYPE')
    if props.get('PTTYPE') and not fs_type:
        raise ValueError('Image de disque partitionné. Choisissez une image de sa partition.')
    if data.get('mode')=='free':
        if fs_type not in ('vfat','exfat','ntfs','ext2','ext3','ext4'):
            raise ValueError('Espace libre impossible à identifier. Pour rechercher aussi les fichiers présents, choisissez « Tout le volume ».')
        if fs_type=='ntfs' or fs_type.startswith('ext'):
            version = subprocess.check_output([tool,'/version'],text=True,timeout=15)
            lib = 'ntfs' if fs_type=='ntfs' else 'ext2fs'
            if lib+' lib:' not in version or lib+' lib: none' in version:
                raise ValueError('Cette version de PhotoRec ne peut pas isoler l’espace libre de ce format.')
    if fs_type:
        data['filesystem'] = 'ext' if fs_type.startswith('ext') else 'other'
    script = photorec_script(source_kind, source, data.get('filesystem','other'),
                             data.get('mode','whole'), data.get('categories',['images']), data.get('families'))
    emit_status(folder, state='running', action='signature', percent=None, count=0,
                result_path=str(output), message='PhotoRec cherche les formats sélectionnés…')
    code = run_process(folder, [tool, '/log', '/d', str(output / 'recup'), '/cmd', source, script], progress_dir=output)
    if code == 0:
        log = folder / 'photorec.log'
        # Scan line by line; log files can be large.
        with log.open(errors='replace') as stream:
            valid = False
            free_verified = False
            for line in stream:
                if 'remove_used_space' in line:
                    free_verified = True
                if 'Pass 1 ' in line or 'Total:' in line:
                    valid = True
                if 'Syntax error' in line:
                    raise ValueError('PhotoRec a refusé la sélection des formats. Consultez photorec.log.')
        if not valid or (data.get('mode')=='free' and not free_verified):
            raise ValueError('PhotoRec n’a pas confirmé la zone analysée. Les éventuels fichiers produits sont à vérifier.')
    n = count_files(output)
    state = 'cancelled' if code == 'cancelled' else ('done' if code == 0 else 'error')
    emit_status(folder, state=state, action='advanced' if combined else 'signature', count=n, result_path=str(output), finished=time.time(),
        message=(f'{n} fichier(s) produits. Contrôlez les résultats avant de les utiliser.'
                 if state == 'done' else 'Analyse arrêtée ou en erreur. Consultez le journal.'))


def run_clone(folder, data, uid):
    source = data['source']
    out = Path(data['destination']).expanduser().absolute()
    if out.suffix.lower() not in ('.img','.dd','.raw'):
        raise ValueError('Choisissez un fichier .img, .dd ou .raw.')
    safe_output(source, out.parent)
    mapfile = Path(str(out) + '.map')
    if mapfile.exists() or mapfile.is_symlink() or out.exists() or out.is_symlink():
        raise ValueError('L’image ou sa carte existe déjà. Choisissez un nouveau nom.')
    tool = shutil.which('ddrescue')
    if not tool:
        raise ValueError('GNU ddrescue est absent.')
    fd = create_as_user(out, uid)
    os.close(fd)
    emit_status(folder, state='running', action='clone', message='Création de l’image disque…')
    code = run_process(folder, [tool,'--no-scrape','--no-trim', source, str(out), str(mapfile)])
    if code == 0:
        # GNU ddrescue can finish with unread areas. Check every data extent.
        extents = [line.split() for line in mapfile.read_text().splitlines()
                   if line and not line.startswith('#') and len(line.split())==3
                   and line.split()[1].startswith('0x')]
        if not extents or any(fields[2]!='+' for fields in extents) or out.stat().st_size!=sum(int(fields[1],16) for fields in extents):
            raise ValueError('Image partielle. Consultez la carte .map pour les zones illisibles.')
    state = 'cancelled' if code == 'cancelled' else ('done' if code == 0 else 'error')
    emit_status(folder, state=state, result_path=str(out), finished=time.time(),
        message='Image disque créée.' if state == 'done' else 'Opération interrompue ou en erreur.')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--job', required=True)
    args = parser.parse_args()
    folder = Path(args.job)
    try:
        folder, data, uid = check_job(folder)
        source_kind = valid_source(data['source'])
        if source_kind=='device' and data.get('device_id')!=device_identity(data['source']):
            raise ValueError('Le support a changé. Actualisez la liste et sélectionnez-le de nouveau.')
        if os.geteuid() == 0:
            raise ValueError('Lancez Récup Studio dans votre session utilisateur.')
        action = data['action']
        if source_kind == 'device':
            from imaging import acquire
            target = Path(data['destination']) if action == 'clone' else folder / 'partition.img'
            safe_output(data['source'], target.parent)
            safe_output(data['source'], folder)
            def progress(percent):
                emit_status(folder, state='running', action=action, percent=percent,
                            message=f'Copie en lecture seule de la partition · {percent} %')
            if action=='clone' and os.access(data['source'], os.R_OK):
                run_clone(folder, data, uid)
                return 0 if read_json(folder/'status.json',{}).get('state')=='done' else 1
            acquire(data['source'], target, lambda: cancelled(folder), progress)
            if action == 'clone':
                emit_status(folder, state='done', action='clone', message='Image complète créée.', result_path=str(target))
                return 0
            data['source'] = str(target)
        source = Path(data['source'])
        info = source.stat()
        identity = [info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns]
        if action == 'restore':
            original = read_json(Path(data['catalog']).parent / 'source.json', {})
            if original.get('identity') != identity or original.get('path') != str(source):
                raise ValueError('Image modifiée depuis la recherche. Relancez l’analyse.')
        if action in ('metadata', 'advanced'):
            atomic_json(folder / 'source.json', {'path':str(source), 'identity':identity})
        if action == 'metadata':
            scan_metadata(folder, data, uid)
        elif action == 'restore':
            restore_metadata(folder, data, uid)
        elif action == 'signature':
            run_signature(folder, data, uid)
        elif action == 'advanced':
            try:
                scan_metadata(folder, data, uid, combined=True)
            except ValueError as exc:
                emit_status(folder, metadata_error=str(exc))
            if cancelled(folder):
                raise InterruptedError('Analyse interrompue.')
            else:
                run_signature(folder, data, uid, combined=True)
        else:
            run_clone(folder, data, uid)
        return 0 if read_json(folder/'status.json',{}).get('state')=='done' else 1
    except InterruptedError as e:
        emit_status(folder, state='cancelled', message=str(e))
        return 1
    except BaseException as e:
        try:
            emit_status(folder, state='error', finished=time.time(), message=str(e))
        except Exception:
            pass
        return 1

if __name__ == '__main__':
    raise SystemExit(main())
