#!/usr/bin/python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Récup Studio's fail-safe launcher and local HTML diagnostic."""
from __future__ import annotations
import datetime
import html
import os
from pathlib import Path
import shutil
import subprocess
import sys
import traceback

STATE = Path.home() / '.local' / 'state' / 'recupstudio'
LOG = STATE / 'startup.log'
REPORT = STATE / 'diagnostic.html'
VERSION = '0.4.0'


def log_message(message):
    try:
        STATE.mkdir(parents=True,exist_ok=True,mode=0o700)
        if LOG.exists() and LOG.stat().st_size > 2_000_000:
            LOG.replace(STATE/'startup.previous.log')
        with LOG.open('a',encoding='utf-8') as file:
            os.chmod(LOG,0o600)
            file.write('['+datetime.datetime.now().astimezone().isoformat(timespec='seconds')+'] '+message+'\n')
    except OSError:
        pass


def show_error(message):
    """Fail-safe native error dialog; no dependency on removed Tkinter UI."""
    try:
        if shutil.which('zenity'):
            subprocess.run(['zenity','--error','--title=Récup Studio — erreur',
                            '--width=530','--text='+message[:2500]],timeout=25,
                           stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
            return
    except Exception:
        pass
    print(message,file=sys.stderr)
    try:
        diagnostic()
    except Exception:
        pass


def diagnostic():
    lines=['Python : '+sys.version.split()[0],
           'Session : '+os.getenv('XDG_SESSION_TYPE','non renseignée')]
    for name in ('lsblk','fls','icat','photorec','ddrescue','udisksctl'):
        lines.append(name+': '+(shutil.which(name) or 'ABSENT'))
    try:
        import gi
        gi.require_version('Gtk', '4.0')
        gi.require_version('Adw', '1')
        from gi.repository import Gtk, Adw
        lines.append('GTK : '+'.'.join(str(v) for v in (Gtk.get_major_version(), Gtk.get_minor_version())))
        lines.append('libadwaita : '+'.'.join(str(v) for v in
            (Adw.get_major_version(),Adw.get_minor_version(),Adw.get_micro_version())))
    except Exception as e:
        lines.append('GTK / libadwaita : '+str(e))
    log='Aucune erreur enregistrée.'
    try:
        log=LOG.read_text(encoding='utf-8',errors='replace')[-18000:]
    except OSError:pass
    jobs=[]
    folder=STATE/'jobs'
    if folder.exists():
        for job in sorted(folder.iterdir(),key=lambda p:p.stat().st_mtime if p.exists() else 0,reverse=True)[:6]:
            if not job.is_dir() or job.is_symlink():continue
            status=job/'status.json'
            if status.exists():
                try:
                    import json
                    obj=json.loads(status.read_text())
                    jobs.append(f"{job.name}: {obj.get('action','?')} — {obj.get('state','?')} — {obj.get('message','?')}")
                except Exception:pass
    STATE.mkdir(parents=True,exist_ok=True,mode=0o700)
    body=f'''<!doctype html><html lang="fr"><head><meta charset="utf-8">
<title>Récup Studio — diagnostic</title><style>body{{font:16px system-ui,sans-serif;
max-width:1050px;margin:30px auto;padding:0 20px;background:#f2f5fa;color:#1c2f4a}}
section{{padding:22px;margin:12px 0;background:white;border-radius:12px}}
pre{{white-space:pre-wrap;overflow-wrap:anywhere;background:#ecf1f9;padding:15px}}
</style></head><body><section><h1>Récup Studio · Diagnostic</h1>
<p>Version {VERSION} · Rapport local du {html.escape(datetime.datetime.now().strftime('%d/%m/%Y %H:%M'))}</p>
<p>Attention : ce rapport contient éventuellement des chemins personnels. Relisez-le avant de le partager.</p></section>
<section><h2>État du système</h2><pre>{html.escape(chr(10).join(lines))}</pre></section>
<section><h2>Dernières tâches</h2><pre>{html.escape(chr(10).join(jobs) if jobs else 'Aucune tâche récente.')}</pre></section>
<section><h2>Journal du démarrage</h2><pre>{html.escape(log)}</pre></section>
</body></html>'''
    REPORT.write_text(body,encoding='utf-8');os.chmod(REPORT,0o600)
    log_message('Diagnostic généré : '+str(REPORT))
    try:subprocess.Popen(['xdg-open',REPORT.as_uri()],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    except Exception:show_error('Rapport enregistré ici : '+str(REPORT))
    return 0


def main():
    if '--diagnostic' in sys.argv:return diagnostic()
    log_message('Ouverture demandée. Python '+sys.version.split()[0]+'.')
    try:
        from app import main as run_application
        code=run_application()
        log_message('Fermeture. Code '+str(code))
        return code
    except BaseException:
        err=traceback.format_exc()
        log_message('ERREUR AU DÉMARRAGE :\n'+err)
        show_error('Récup Studio ne peut pas se lancer. '+err[-500:])
        return 1

if __name__=='__main__':raise SystemExit(main())
